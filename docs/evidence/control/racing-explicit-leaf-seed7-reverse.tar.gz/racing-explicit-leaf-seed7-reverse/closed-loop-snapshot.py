"""Retest only explicit leaf action descriptions; original coarse tree unchanged."""
import argparse
import json
import shutil
from pathlib import Path

import probe


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, required=True)
    parser.add_argument('--reverse', action='store_true')
    args = parser.parse_args()
    racing = probe.racing
    original_decode = racing.decode_action

    def decode(client, state, reverse=False):
        return original_decode(probe.RequestVariant(client, 'explicit-leaf-actions'), state, reverse)

    racing.decode_action = decode
    racing.ROOT = Path(__file__).resolve().parent / 'explicit-leaf-actions'
    racing.ROOT.mkdir(exist_ok=True)
    racing.credentials()
    summary = racing.play('NumericJev', args.seed, args.reverse)
    out = Path(summary['video']).parent
    shutil.copy2(__file__, out / 'closed-loop-snapshot.py')
    shutil.copy2(probe.__file__, out / 'probe-snapshot.py')
    summary['variant'] = 'explicit-leaf-actions'
    summary['changes_from_baseline'] = 'Only final-level option descriptions and question instructions describe exact executed commands and action effects. Coarse tree, grid, input state, rules, action execution and stop limits unchanged.'
    (out / 'summary.json').write_text(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
