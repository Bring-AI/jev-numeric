"""Fixed-state policy/representation ablations. Does not modify original runs."""
import concurrent.futures
import copy
import importlib.util
import json
import random
import sys
from decimal import Decimal
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
spec = importlib.util.spec_from_file_location('racing', BASE / 'run.py')
racing = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = racing
spec.loader.exec_module(racing)

LIVENESS = (' Slow down for bends, but do not stop to turn. Steering cannot rotate this car in place: '
            'it must move forward to turn. When the car is stopped or moving very slowly on the road, '
            'release the brake and apply positive throttle while steering toward the road. '
            'Coasting at zero speed will leave the car stationary. Reassess the current speed each time; '
            'do not keep braking merely because the road bends.')
VARIANTS = ('original', 'prompt-liveness', 'explicit-leaf-actions', 'remove-previous', 'semantic-intent', 'history-window')


class RequestVariant:
    def __init__(self, client, variant):
        self.client = client
        self.variant = variant
        self.depth = 0

    def ask(self, state, questions):
        state, questions = copy.deepcopy(state), copy.deepcopy(questions)
        if self.variant == 'prompt-liveness':
            state['rules'] += LIVENESS
        elif self.variant == 'remove-previous':
            del state['telemetry']['previous_commands']
        elif self.variant == 'explicit-leaf-actions' and self.depth == 1:
            for name, q in questions.items():
                q['instructions'] = ('Choose the best exact command to execute for the next 0.20 seconds '
                                     'of driving under the given rules and telemetry. Each option describes '
                                     'the actual action that will execute, not a target speed or angle.')
                for key, description in q['criteria'].items():
                    value = Decimal(description.split(' <= ')[0])
                    if name == 'signed_acceleration':
                        effect = (f'BRAKE intensity {abs(value)}; throttle zero' if value < 0 else
                                  f'THROTTLE intensity {value}; brake zero' if value > 0 else
                                  'COAST: throttle zero and brake zero; a stationary car will remain stationary')
                    else:
                        effect = (f'Steer LEFT, magnitude {abs(value)}' if value < 0 else
                                  f'Steer RIGHT, magnitude {value}' if value > 0 else 'STEER STRAIGHT')
                    q['criteria'][key] = f'Execute {name}={value}. {effect}.'
        self.depth += 1
        return self.client.ask(state, questions)


def one(job):
    state_name, telemetry, variant, reverse = job
    name = f'{state_name}--{variant}--{"reverse" if reverse else "forward"}'
    client = racing.JevClient(max_calls=2, model=racing.MODEL)
    state = {'rules': racing.RULES, 'telemetry': telemetry}
    result = {'state': state_name, 'variant': variant, 'reverse': reverse}
    try:
        if variant == 'semantic-intent':
            criteria = {'brake': 'Apply braking to reduce speed.',
                        'coast': 'Apply neither throttle nor brake.',
                        'throttle': 'Apply positive throttle to increase forward motion.'}
            if reverse:
                criteria = dict(reversed(list(criteria.items())))
            answer = client.ask(state, {'longitudinal_intent': {
                'type': 'choice', 'instructions': 'Choose the best longitudinal action for the next 0.20 seconds of driving under the given rules and telemetry.',
                'criteria': criteria}})['answers']['longitudinal_intent']
            result['intent'] = answer['choice']
            result['probabilities'] = answer['probabilities']
        else:
            action, trace = racing.decode_action(RequestVariant(client, variant), state, reverse)
            result.update(command=action, trace=trace)
        result['calls'] = client.calls
    except Exception as e:
        result['error'] = str(e)
    finally:
        (HERE / 'probes' / f'{name}.json').write_text(json.dumps({'result': result, 'records': client.records}, indent=2))
        client.close()
    print(json.dumps(result), flush=True)
    return result


def main():
    racing.credentials()
    (HERE / 'probes').mkdir(exist_ok=True)
    states = []
    for folder, index, name in [('NumericJev-seed7', 14, 'fast-bend'),
                                ('NumericJev-seed7', 15, 'slow-bend'),
                                ('NumericJev-seed7', 20, 'stopped-seed7'),
                                ('NumericJev-seed19', 20, 'stopped-seed19')]:
        rows = [json.loads(x) for x in (BASE / folder / 'actions.jsonl').read_text().splitlines()]
        history = [{'sim_time_s': r['step'] / racing.FPS, 'speed_before_action': r['telemetry']['speed'],
                    'road_heading_right_degrees': r['telemetry']['road_heading_right_degrees'],
                    'steering': r['command'][0], 'signed_acceleration': r['command'][1],
                    'visited_tiles_after_action': r['visited_tiles']} for r in rows[max(0,index-6):index]]
        states.append((name, rows[index]['telemetry'], history))
    jobs = []
    for name, state, history in states:
        for variant in VARIANTS:
            for reverse in (False, True):
                telemetry = copy.deepcopy(state)
                if variant == 'history-window':
                    telemetry['recent_history_oldest_first'] = history
                jobs.append((name, telemetry, variant, reverse))
    random.Random(7).shuffle(jobs)
    (HERE / 'protocol.json').write_text(json.dumps({
        'purpose': 'Distinguish prompt, leaf representation, previous-action context, and numerical choice effects at fixed states.',
        'states': states, 'variants': VARIANTS, 'liveness_appendix': LIVENESS,
        'orders': ['forward', 'reverse'], 'repetitions': 1,
        'job_order': [[j[0], j[2], j[3]] for j in jobs],
        'limitations': 'Four selected diagnostic states, one query per condition. No statistical generalization or policy benchmark.'
    }, indent=2))
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(one, jobs))
    (HERE / 'probe-results.json').write_text(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
