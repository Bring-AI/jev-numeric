"""Sequential Jev gait plus FIXED0 support-angle template. Every motor remains NumericJev-selected."""
import importlib.util,json,argparse,shutil
spec=importlib.util.spec_from_file_location('w','/data/yww/notebook/numericjev-game-experiments/prompt-recovery-20260924/bipedalwalker/run_walker.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w);b=w.b
class Sequential(w.Controller):
 def __init__(self,variant):super().__init__(variant);self.p=1;self.m=0;self.k=0.0
 def decode(self,client,config,state,reverse,path):
  o=state['observation']
  if self.variant in ('v10_rounded','v11_pure_arithmetic'):
   o=json.loads(json.dumps(o),parse_float=lambda x:round(float(x),3))
  m=self.m;u=1-m;p=self.p;k=self.k;ml=o[f'leg{m}'];ul=o[f'leg{u}'];vx=o['vx_scaled'];prior={'phase':p,'moving_leg':m,'knee_memory':k}
  status=f"Previous phase={p} (1 SWING,2 LOWER,3 PUSH), moving leg={m}, supporting leg={u}. Current support hip={ul['hip_angle']}, moving foot contact={ml['ground_contact']}, support knee={ul['knee_angle_plus1']}, vx={vx}. "
  rules='''Choose the gait action-case by applying these conditions exactly. If previous phase1 and support hip>=0.10: SWING. If previous phase1 and support hip<0.10, or previous phase2: enter LOWER. In LOWER, if moving foot contact=0 choose LOWER; if contact=1 choose LOWER_PUSH, preserving the hip-lowering goal while pushing. If previous phase3 choose PUSH. For LOWER_PUSH or PUSH only: if support knee>0.88 OR vx>0.348, append SWITCH; otherwise keep same moving leg. SWITCH changes next-step memory, not current action goals. Do not switch just because one foot touched. Conditions are on the raw values listed above.'''
  kinds=['SWING','LOWER','LOWER_PUSH','LOWER_PUSH_SWITCH','PUSH','PUSH_SWITCH']
  q={'gait_case':{'type':'choice','instructions':status+rules,'criteria':{str(i):kind+f' moving leg{m}, supporting leg{u}'+(f'; after this action next moving leg{u}' if 'SWITCH' in kind else '') for i,kind in enumerate(kinds)}}}
  if self.variant in ('v13_phase_predicates','v14_inequality','v15_fixed0_inequality'):
   if p==1:
    kinds=['SWING','LOWER','LOWER_PUSH','LOWER_PUSH_SWITCH']
    criteria=[f"support hip {ul['hip_angle']} >=0.10: SWING moving leg{m}. IGNORE vx and foot contact in this case.",f"support hip {ul['hip_angle']} <0.10 AND moving foot contact {ml['ground_contact']}=0: LOWER moving leg{m}. IGNORE vx; an airborne foot cannot push or switch.",f"support hip {ul['hip_angle']} <0.10 AND moving foot contact {ml['ground_contact']}=1 AND support knee {ul['knee_angle_plus1']}<=0.88 AND vx {vx}<=0.348: LOWER then PUSH, keep current moving leg.",f"support hip {ul['hip_angle']} <0.10 AND moving foot contact {ml['ground_contact']}=1 AND (support knee {ul['knee_angle_plus1']}>0.88 OR vx {vx}>0.348): LOWER then PUSH then SWITCH next-step moving leg."]
   elif p==2:
    kinds=['LOWER','LOWER_PUSH','LOWER_PUSH_SWITCH']
    criteria=[f"moving foot contact {ml['ground_contact']}=0: stay LOWER. IGNORE vx; airborne foot cannot push or switch.",f"moving foot contact {ml['ground_contact']}=1 AND support knee {ul['knee_angle_plus1']}<=0.88 AND vx {vx}<=0.348: LOWER then PUSH, no switch.",f"moving foot contact {ml['ground_contact']}=1 AND (support knee {ul['knee_angle_plus1']}>0.88 OR vx {vx}>0.348): LOWER then PUSH then SWITCH."]
   else:
    kinds=['PUSH','PUSH_SWITCH'];criteria=[f"support knee {ul['knee_angle_plus1']}<=0.88 AND vx {vx}<=0.348: PUSH without switching",f"support knee {ul['knee_angle_plus1']}>0.88 OR vx {vx}>0.348: PUSH then SWITCH next moving leg"]
   q['gait_case']['instructions']=status+'Choose the ONE candidate whose entire logical condition is true. AND requires EVERY condition, so fast vx alone never permits a switch when the moving foot is airborne. Evaluate support hip first, then foot contact, and only finally speed/knee threshold. All raw measurements appear in criteria.'
   q['gait_case']['criteria']={str(i):v for i,v in enumerate(criteria)}
  r=self.ask(client,{'task':'Choose gait case before motor questions'},q,path,'sequential_gait_case');kind=kinds[int(r['answers']['gait_case']['choice'])]
  if kind=='SWING':self.p=1
  elif kind=='LOWER':self.p=2
  elif 'SWITCH' in kind:self.p=1;self.m=u
  else:self.p=3
  # Disclosed policy constant: support knee ANGLE is fixed0, not a motor action.
  self.k=0.0
  goals={f'leg{u}_hip':None,f'leg{m}_hip':1.1 if kind=='SWING' else .1 if kind.startswith('LOWER') else None,f'leg{m}_knee':-.6 if kind=='SWING' else .1 if kind=='LOWER' else self.k,f'leg{u}_knee':self.k if kind in ('SWING','LOWER') else 1.}
  trace=[{'previous_model_memory':prior,'model_chosen_gait_case':kind,'next_model_memory':{'phase':self.p,'moving_leg':self.m,'knee_memory':self.k},'disclosed_angle_goal_template':goals}];windows={n:(0,400) for n in config['names']}
  for depth in range(2):
   qs={};cb={}
   for name,(lo,hi) in windows.items():
    i=int(name[3]);joint=name.split('_')[1];l=o[f'leg{i}'];goal=goals[name];cuts=b.partitions(lo,hi);cb[name]=cuts
    if joint=='hip':expr=(f'0.495*({goal}-({l["hip_angle"]}))-0.1375*({l["hip_speed"]})+' if goal is not None else '')+f'0.495*({o["torso_angle"]})+0.825*({o["torso_angular_velocity_scaled"]})'
    else:expr=f'2.2*({goal}-({l["knee_angle_plus1"]}))-0.1375*({l["knee_speed"]})-8.25*({o["vy_scaled"]})'
    ins=f'Compute motor torque {name} from {expr}. Clamp result to [-1,0.995]. Select interval containing the result. The gait case {kind} was already chosen by you; angle goal {goal} is a fixed template value or your chosen knee memory. Do not use that angle goal as motor torque. Subtraction of negative is addition.'
    if self.variant=='v10_sequential_cases':
     angle=l['hip_angle'] if joint=='hip' else l['knee_angle_plus1'];speed=l['hip_speed'] if joint=='hip' else l['knee_speed']
     ins+=f' Current angle={angle}, target={goal}, speed={speed}. Target above current angle means POSITIVE feedback; target below current angle means NEGATIVE feedback. Speed damping opposes joint motion. Downward torso speed adds positive knee feedback. Use balance correction when no hip target.'
    if self.variant=='v12_fall_extension' and joint=='knee':
     ins=f'HIGHEST PRIORITY FALL RECOVERY: Current UPWARD torso velocity is {o["vy_scaled"]}. If this is below -0.12, the body is falling fast: choose MAXIMUM POSITIVE knee torque +0.995 to EXTEND the leg and catch the body. In that case select the HIGHEST offered interval, even if the gait goal says bend; positive torque extends, negative torque folds the leg. Only if velocity is -0.12 or higher use the following ordinary rule. '+ins
    if self.variant=='v11_pure_arithmetic':ins=f'Evaluate ({expr}). Clamp the number to [-1,0.995]. Select the numerical interval containing that result. Subtracting a negative is addition. Bounds are lower inclusive.'
    qs[name]={'type':'choice','instructions':ins,'criteria':{str(j):f'{b.grid_value(cuts[j])} <= torque < {b.grid_value(cuts[j+1])}' for j in range(len(cuts)-1)}}
    if self.variant in ('v14_inequality','v15_fixed0_inequality'):
     labels={}
     for j,(a,z) in enumerate(zip(cuts,cuts[1:])):
      low,high=b.grid_value(a),b.grid_value(z)
      if a==0:label=f'({expr}) < {high}; clipped interval [{low},{high})'
      elif z==400:label=f'({expr}) >= {low}; clipped interval [{low},{high})'
      else:label=f'({expr}) >= {low} AND ({expr}) < {high}; interval [{low},{high})'
      labels[str(j)]=label
     qs[name]={'type':'choice','instructions':'Select the ONE true arithmetic inequality among the options. Each option substitutes the complete same expression; compare its signed value to the displayed bounds. No game prediction is required. The range is clipped to[-1,0.995], so endpoint options also include more extreme raw results. Do not read option labels as numeric values.','criteria':labels}

   r=self.ask(client,{'task':'Calculate each focused motor equation; no previous motor commands'},qs,path,'motor_interval')
   for n,a in r['answers'].items():j=int(a['choice']);windows[n]=(cb[n][j],cb[n][j+1])
   trace.append({'depth':depth,'windows':dict(windows),'choices':{n:a['choice'] for n,a in r['answers'].items()}})
  return [float(b.LOW+b.RESOLUTION*windows[n][0]) for n in config['names']],trace
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--variant',default='v15_fixed0_inequality');p.add_argument('--seed',type=int,default=7);p.add_argument('--hold',type=int,default=1);args=p.parse_args();b.credentials();b.CONFIG['bipedalwalker'].update(rules=w.RULES+' Sequential gait cases preserve chained reference transitions and hip goals. Support knee ANGLE is a disclosed fixed0.0 constant. Model selects gait then all motor torques; no dynamic knee memory.',hold=args.hold,guidance='Sequential Jev gait case with explicit predicate candidates; fixed0.0 support-knee ANGLE template replaces dynamic memory; NumericJev motor choices use true-inequality candidates. No Python motor computation.')
 ctl=Sequential(args.variant);b.decode_action=ctl.decode;old=b.JevClient;b.JevClient=lambda **kw:old(**dict(kw,max_calls=8200));a=args.variant+f'-hold{args.hold}';summary=b.play('bipedalwalker',args.seed,attempt=a,wall_limit=3600);out=w.ROOT/summary['id'];shutil.copy2(__file__,out/'prompt-runner-snapshot.py');shutil.copy2(w.__file__,out/'imported-walker-runner.py');summary['intermediate_gait_protocol']='Three sequential API calls per motor decision: model gait case1, four motor numerical refinements2. Support knee angle is a fixed disclosed0.0 policy constant. Templates choose ANGLE goals only; actual torques all model-selected. Controlfrequency hold1.';(out/'summary.json').write_text(json.dumps(summary,indent=2))
