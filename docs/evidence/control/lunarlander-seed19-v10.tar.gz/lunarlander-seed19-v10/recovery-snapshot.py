"""Prompt-only recovery. All executed actions are actual Jev interval choices."""
from pathlib import Path
import sys, json, importlib.util, time, shutil, argparse
HERE=Path(__file__).resolve().parent
BASE=Path('/data/yww/notebook/numericjev-game-experiments/multigame-20260924/games/run_games.py')
spec=importlib.util.spec_from_file_location('base_runner',BASE)
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
b.ROOT=HERE
VARIANT='v5'
MAIN='''Choose the main_engine command for LunarLander. Calculate the numerical command yourself from observation. Main control law: u = 5.5*abs(x) - 10*y - 10*vy - 1. If either leg has contact, instead u=-10*vy-1. Clamp u to [-1,0.995]. Choose the interval that contains this clamped value. Negative vy means falling, so subtracting 10*vy contributes POSITIVELY; high y contributes NEGATIVELY. main_engine<=0 turns the engine OFF. A positive action turns engine ON at power=(action+1)/2. Positive thrust brakes downward velocity. This explicit arithmetic law is the decision policy; compute it anew from current observation, rather than guessing a number from the altitude alone.'''
SIDE='''Choose the lateral_engine command for LunarLander. Calculate the numerical command yourself from observation. First compute t = 0.5*x + vx; clamp t to [-0.4,+0.4]. Then compute u = 10*angle + 20*angular_velocity - 10*t; clamp u to [-1,0.995]. If either leg contacts the ground, use u=0 instead. Choose the interval containing this clamped u. Positive lateral_engine rotates CLOCKWISE and makes angle DECREASE; negative rotates COUNTERCLOCKWISE and makes angle INCREASE. Negative x and negative vx give NEGATIVE t, and subtracting negative t contributes POSITIVELY to u. Positive angle and positive angular_velocity contribute POSITIVELY. |lateral_engine|<=0.5 is OFF. Do not choose 0.5 if you need positive torque; choose >0.5. This arithmetic law is the decision policy; compute it from current observation.'''

def question(name,state,depth):
    p=MAIN if name=='main_engine' else SIDE
    if VARIANT in ('v6','v11'):
        p=('Compute exactly, in order, without skipping signs. '+p+'\nCURRENT OBSERVATION: '+json.dumps(state['observation']))
    elif VARIANT in ('v7','v10'):
        p=('The goal is to evaluate a numerical expression and classify its result into a numeric interval. '+p)
    elif VARIANT=='v8':
        if name=='main_engine': p='''Choose the interval containing clamp(5.5*abs(observation.x)-10*observation.y-10*observation.vy-1,-1,0.995). If either leg contact is nonzero choose clamp(-10*observation.vy-1,-1,0.995) instead. Compute the expression from the supplied state yourself. Do not assume zero. This is an arithmetic evaluation question.'''
        else: p='''Choose the interval containing clamp(10*observation.angle+20*observation.angular_velocity-10*clamp(0.5*observation.x+observation.vx,-0.4,0.4),-1,0.995). If either leg contact is nonzero choose 0 instead. Compute the expression from the supplied state yourself. Positive angle and angular velocity require positive command; negative position and velocity usually also require positive command. This is an arithmetic evaluation question.'''
    elif VARIANT=='v9':
        o=state['observation']
        if name=='main_engine': p=f'''Evaluate and clamp to [-1,0.995]: 5.5*abs({o['x']}) - 10*({o['y']}) - 10*({o['vy']}) - 1. If leg0_contact={o['leg0_contact']} or leg1_contact={o['leg1_contact']} is 1, use -10*({o['vy']})-1 instead. Select the numeric interval containing your result. No result is supplied; you must calculate it.'''
        else: p=f'''Evaluate t=clamp(0.5*({o['x']})+({o['vx']}),-0.4,0.4). Then evaluate u=clamp(10*({o['angle']})+20*({o['angular_velocity']})-10*t,-1,0.995). If leg0_contact={o['leg0_contact']} or leg1_contact={o['leg1_contact']} is 1, use u=0 instead. Select the interval containing your result. No result is supplied; you must calculate it.'''
    return p+' Intervals are lower-inclusive and upper-exclusive. Final lower endpoint is executed, for 5 physics steps. Maximum representable control is 0.995. Refine the SAME calculation at every depth; labels are only identifiers, not commands.'

def decode(client,config,state,reverse,log_path):
    if VARIANT in ('v10','v11','v12'): state={'observation':state['observation'],'simulation_step':state['simulation_step'],'action_hold_frames':5}
    windows={n:(0,400) for n in config['names']};trace=[];depth=0
    while any(r-l>1 for l,r in windows.values()):
        questions={};cb={}
        for name,(left,right) in windows.items():
            if right-left==1:continue
            cuts=b.partitions(left,right);cb[name]=cuts
            criteria={}
            for i in range(len(cuts)-1):
                lo,hi=b.grid_value(cuts[i]),b.grid_value(cuts[i+1]); a=float(lo); z=float(hi)
                label=f'{lo} <= command < {hi}'
                if depth==1 and VARIANT!='v8':
                    if name=='main_engine': effect='engine OFF' if a<=0 else f'engine ON, thrust {(a+1)/2:.4f}'
                    else:effect='side engine OFF' if abs(a)<=.5 else ('CLOCKWISE, angle decreases' if a>.5 else 'COUNTERCLOCKWISE, angle increases')
                    label+=f'; executed command={lo}; {effect}'
                criteria[f'c{i:02d}']=label
            if reverse:criteria=dict(reversed(list(criteria.items())))
            questions[name]={'type':'choice','instructions':question(name,state,depth),'criteria':criteria}
        request={'model':b.MODEL,'state':state,'questions':questions};start=time.monotonic()
        try: response=client.ask(state,questions)
        except Exception as exc:
            with log_path.open('a') as f:f.write(json.dumps({'request':request,'error':str(exc),'latency_s':time.monotonic()-start})+'\n')
            raise
        with log_path.open('a') as f:f.write(json.dumps({'request':request,'response':response,'latency_s':time.monotonic()-start})+'\n')
        for name,answer in response['answers'].items():
            choice=int(answer['choice'][1:]);cuts=cb[name];windows[name]=(cuts[choice],cuts[choice+1])
        trace.append({'depth':depth,'windows':dict(windows),'choices':{n:a['choice'] for n,a in response['answers'].items()}});depth+=1
    action=[float(b.LOW+b.RESOLUTION*windows[n][0]) for n in config['names']]
    assert depth==2 and all(-1<=a<1 for a in action)
    return action,trace

b.decode_action=decode

def play(seed):
    result=b.play('lunarlander',seed,attempt=VARIANT,wall_limit=1600)
    out=HERE/result['id'];shutil.copy2(__file__,out/'recovery-snapshot.py')
    result['prompt_variant']=VARIANT;result['changes_from_original']='Full per-axis rules in question.instructions; criterion identifiers c00..c19; exact effect labels at leaves. v9 substitutes observed numeric values into the unevaluated expression. No Python target computation.'
    (out/'summary.json').write_text(json.dumps(result,indent=2))
    return result

def probes():
    rows=[json.loads(x) for x in (BASE.parent/'lunarlander-seed7-v2/actions.jsonl').read_text().splitlines()]
    c=b.CONFIG['lunarlander'];client=b.JevClient(max_calls=100,model=b.MODEL);results=[]
    global VARIANT
    for VARIANT in ['v5','v6','v7','v8','v9']:
        for i in [0,7,11]:
            r=rows[i];state={'observation':r['observation'],'simulation_step':r['step'],'action_hold_frames':5}
            action,trace=decode(client,c,state,False,HERE/'fixed-state-api-records.jsonl')
            result={'variant':VARIANT,'source':'lunarlander-seed7-v2','step':r['step'],'observation':r['observation'],'action':action};results.append(result);print(json.dumps(result),flush=True)
            (HERE/'fixed-state-results.json').write_text(json.dumps(results,indent=2))
    client.close()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--probe',action='store_true');p.add_argument('--variant',default='v5');p.add_argument('--seeds',type=int,nargs='+',default=[7]);args=p.parse_args();b.credentials();VARIANT=args.variant
    if args.probe:probes()
    else:
        for seed in args.seeds:play(seed)
