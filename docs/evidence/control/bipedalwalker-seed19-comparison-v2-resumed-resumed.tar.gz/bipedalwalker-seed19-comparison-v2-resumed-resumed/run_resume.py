"""Continue a transport-interrupted episode using its exact frozen model prefix."""
import json
import argparse
from pathlib import Path
import shutil
from run_comparison import ROOT, b, ComparisonWalker
from resume_transport import ResumeTransport

parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, required=True, help='Archived API-interrupted run directory')
args = parser.parse_args()
source = args.source.resolve()
assert source.parent == ROOT/'runs'
prior = json.loads((source/'summary.json').read_text())
assert prior['stop_reason'] == 'api_or_runner_error' and not prior['terminated'] and not prior['truncated']
prefix = [json.loads(line) for line in (source/'api-records.jsonl').read_text().splitlines()]
out = ROOT/'runs'/(source.name+'-resumed')
assert prior['seed'] == 19 and prior['protocol'] == 'comparison-v2'
assert not out.exists(), 'Never overwrite a prior attempt.'
b.ROOT = ROOT/'runs'
b.credentials()
b.CONFIG['bipedalwalker'].update(hold=1, guidance=prior['guidance'],
    rules='The unchanged comparison-v2 protocol continues from an exact recorded response prefix. '
          'All new requests use live Jev; only transport failures are retried. No action override.')
b.decode_action = ComparisonWalker().decode
client_type = b.JevClient
instances = []


def make_client(**kwargs):
    network = client_type(**dict(kwargs, max_calls=3000))
    wrapped = ResumeTransport(network, prefix, out/'response-origin.jsonl', out/'transport-events.jsonl')
    instances.append(wrapped)
    return wrapped


b.JevClient = make_client
snapshot = ROOT/'snapshots/comparison-v2'
for filename, source_name in [('prompt-runner-snapshot.py','run_comparison.py'),
                              ('compositional-snapshot.py','compositional.py'),
                              ('comparison-snapshot.py','comparison.py')]:
    assert (snapshot/filename).read_bytes() == (ROOT/source_name).read_bytes()
resume_snapshot = ROOT/'snapshots/resume-v2'
resume_snapshot.mkdir(parents=True, exist_ok=True)
for name in ['run_resume.py', 'resume_transport.py']:
    target = resume_snapshot/name
    input_file = Path(__file__) if name == 'run_resume.py' else ROOT/name
    assert not target.exists() or target.read_bytes() == input_file.read_bytes()
    shutil.copy2(input_file, target)

result = b.play('bipedalwalker', 19, attempt=out.name.split('-seed19-',1)[1], wall_limit=3600)
client = instances[0]
for path in snapshot.iterdir():
    shutil.copy2(path, out/path.name)
for path in resume_snapshot.iterdir():
    shutil.copy2(path, out/path.name)
for key in ['protocol','coefficients','state_access','intermediate_gait_protocol','grid',
            'executed_action_overrides','difference_from_direct_decoder']:
    result[key] = prior[key]
result.update(resume_snapshot_id='resume-v2', continuation_of=prior['id'], prefix_physics_frames=prior['steps'],
    cached_prefix_requests=len(prefix), new_network_attempts=client.network.calls,
    api_calls=prior['api_calls']+client.network.calls,
    successful_logical_responses=len(client.records),
    resume_session_wall_seconds=result['wall_seconds'], source_session_wall_seconds=prior['wall_seconds'],
    wall_seconds=result['wall_seconds']+prior['wall_seconds'],
    resume_session_mean_action_latency_s=result['mean_action_latency_s'],
    source_session_mean_action_latency_s=prior['mean_action_latency_s'],
    mean_action_latency_s=None, p95_action_latency_s=None,
    latency_note='Full-trajectory mean omitted: the prefix is exactly replayed from archived responses, not re-inferred. Source and resume-session means are separate; resume-session mean includes fast cached-prefix replay. Total wall time sums both recorded sessions, excluding the between-session debugging gap.',
    continuation_note='Same seed, frozen controller, and exact previously returned model responses. Every cached request payload is checked for identity. This continues the interrupted trajectory and is not an independent fresh rollout.')
(out/'summary.json').write_text(json.dumps(result, indent=2))
print('FINAL_RESUMED_RESULT '+json.dumps({key:result[key] for key in ['id','steps','success','stop_reason','reward','api_calls','new_network_attempts']}), flush=True)
