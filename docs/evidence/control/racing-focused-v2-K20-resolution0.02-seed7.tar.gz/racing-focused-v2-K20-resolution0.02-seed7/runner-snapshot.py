"""Exploratory CarRacing control with live NumericJev decisions; no training."""
import os
os.environ.setdefault('SDL_VIDEODRIVER', 'dummy')
os.environ.setdefault('SDL_AUDIODRIVER', 'dummy')
os.environ.setdefault('PYGAME_HIDE_SUPPORT_PROMPT', '1')

import argparse
import hashlib
import json
import math
import sys
import shutil
import time
from decimal import Decimal
from pathlib import Path

import gymnasium as gym
import imageio.v2 as imageio
import numpy as np
from dotenv import load_dotenv
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, '/data/yww/notebook/jev-numeric/src')
from jev_numeric import JevClient

ROOT = Path(__file__).resolve().parent
FPS = 50
HOLD = 10
MAX_STEPS = 3000
STALL_STEPS = 500
MODEL = 'typesafe/jev-1.13-20260917'
RULES = '''Drive forward around the closed track, visiting new road tiles while staying on the road. You control steering and signed acceleration directly. No other controller corrects your actions. The simulation pauses while you decide, and holds your commands for 0.20 simulation seconds (10 physics frames). Positive steering turns RIGHT; negative steering turns LEFT. Zero steering is straight. Steering is sensitive: magnitudes around 0.05-0.15 are gentle, 0.2-0.4 are stronger, 1 is extreme. Positive signed acceleration is throttle; negative signed acceleration is braking; zero coasts. Prefer moderate forward speed around 20-30 simulation units/second, slower in sharp turns or when recovering from grass. Aim toward the near and middle future road-center waypoints. Anticipate upcoming bends; reduce throttle or brake if too fast. Do not keep steering into a turn when yaw is already bringing the car back toward alignment. Positive right offsets and bearing angles mean that the road target is to the RIGHT of the car; negative values mean LEFT. All geometry is already in the car's current coordinate frame. Infer control commands from the situation; commands are not the angles, speed or coordinates themselves.'''


def credentials():
    for name in ('jev-rl-reward', 'jev-continuous', 'jev-numeric'):
        base = Path('/data/yww/notebook') / name
        load_dotenv(base / '.env', override=False)
        keyname = 'OPENROUTER_API_KEY_FILE'
        if keyname in os.environ:
            p = Path(os.environ[keyname]).expanduser()
            if not p.is_absolute() and (base / p).is_file():
                os.environ[keyname] = str(base / p)
    os.environ['JEV_GATEWAY'] = 'openrouter'


def telemetry(env, previous):
    car = env.car.hull
    pos = np.array(car.position, dtype=float)
    points = np.asarray([(x[2], x[3]) for x in env.track])
    # Project onto the nearest centerline segment, not merely the nearest vertex.
    seg = np.roll(points, -1, axis=0) - points
    t = np.clip(np.sum((pos - points) * seg, axis=1) / np.sum(seg * seg, axis=1), 0, 1)
    projected = points + t[:, None] * seg
    idx = int(np.argmin(np.linalg.norm(projected - pos, axis=1)))
    forward = np.array(car.GetWorldVector((0, 1)))
    right = np.array(car.GetWorldVector((1, 0)))
    velocity = np.array(car.linearVelocity)
    tangent = seg[idx] / np.linalg.norm(seg[idx])
    road_error = projected[idx] - pos
    waypoints = []
    for ahead in (2, 4, 8, 12, 16):
        delta = points[(idx + ahead) % len(points)] - pos
        f, r = float(delta @ forward), float(delta @ right)
        waypoints.append({'tiles_ahead': ahead, 'forward': round(f, 2), 'right': round(r, 2), 'bearing_right_degrees': round(math.degrees(math.atan2(r, f)), 2)})
    contact = sum(bool(w.tiles) for w in env.car.wheels)
    return {
        'speed': round(float(np.linalg.norm(velocity)), 2),
        'forward_speed': round(float(velocity @ forward), 2),
        'rightward_slip_speed': round(float(velocity @ right), 2),
        'clockwise_yaw_rate_degrees_per_second': round(-math.degrees(car.angularVelocity), 2),
        'road_heading_right_degrees': round(math.degrees(math.atan2(tangent @ right, tangent @ forward)), 2),
        'road_center_right_offset': round(float(road_error @ right), 2),
        'distance_from_road_center': round(float(np.linalg.norm(road_error)), 2),
        'road_half_width': 6.67,
        'wheels_touching_road': contact,
        'future_centerline_waypoints': waypoints,
        'previous_commands': {'steering': float(previous[0]), 'signed_acceleration': float(previous[1])},
    }


def decode_action(client, state, reverse=False):
    # Two levels, ten options per level, 100 values per command.
    windows = {'steering': (0, 100), 'signed_acceleration': (0, 100)}
    desc = {'steering': 'steering command in [-1,1), negative LEFT and positive RIGHT', 'signed_acceleration': 'signed acceleration command in [-1,1), negative BRAKE and positive THROTTLE'}
    trace = []
    for depth in range(2):
        questions, partitions = {}, {}
        for name, (left, right) in windows.items():
            cuts = [left + (right-left)*i//10 for i in range(11)]
            partitions[name] = cuts
            def value(i): return str(Decimal('-1') + Decimal('.02') * i)
            criteria = {str(i): f'{value(cuts[i])} <= {name} < {value(cuts[i+1])}' for i in range(10)}
            if reverse: criteria = dict(reversed(list(criteria.items())))
            questions[name] = {'type':'choice', 'instructions': f'Choose the best {desc[name]} for the next 0.20 seconds of driving under the given rules and telemetry. Select the interval containing your intended command; bounds are lower-inclusive and upper-exclusive. Labels identify intervals, not command values. At the final level the lower endpoint will be executed.', 'criteria':criteria}
        answers = client.ask(state, questions)['answers']
        for name, answer in answers.items():
            label = int(answer['choice']); cuts=partitions[name]
            windows[name] = (cuts[label],cuts[label+1])
        trace.append({'depth':depth,'windows':dict(windows)})
    result = [float(Decimal('-1') + Decimal('.02') * windows[name][0]) for name in ('steering','signed_acceleration')]
    assert all(-1 <= x <= 1 for x in result)
    return result, trace


def reference_action(state):
    # A transparent geometry controller used only as a separate reference episode.
    wp = state['future_centerline_waypoints'][1]
    alpha = math.atan2(wp['right'], wp['forward'])
    lookahead = max(4, math.hypot(wp['right'], wp['forward']))
    steering = np.clip(math.atan2(2 * 4.8 * math.sin(alpha), lookahead) + .025 * state['rightward_slip_speed'], -.6, .6)
    curve = abs(state['future_centerline_waypoints'][3]['bearing_right_degrees'])
    target = float(np.clip(32 - .4*curve, 15, 32))
    error = target-state['speed']
    longitudinal = np.clip(error * (.025 if error >= 0 else .025), -.3, .25)
    return [float(steering), float(longitudinal)]


def annotate(frame, method, step, env, score, command):
    image = Image.fromarray(frame)
    draw=ImageDraw.Draw(image)
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',14)
    draw.rectangle((0,0,600,58),fill=(18,25,38))
    draw.text((10,5),f'{method} | {step/FPS:4.1f}s | track {100*env.tile_visited_count/len(env.track):5.1f}% | score {score:.1f}',font=font,fill='white')
    draw.text((10,24),f'steer {command[0]:+.2f}   throttle/brake {command[1]:+.2f}   speed {env.car.hull.linearVelocity.length:.1f}',font=font,fill=(143,197,255))
    draw.text((10,41),'Structured state input; simulation-time replay (API waits omitted)',font=font,fill=(188,194,206))
    return np.array(image)


def play(method, seed, reverse=False, limit=MAX_STEPS):
    name=f'{method}-seed{seed}' + ('-reverse' if reverse else '')
    out=ROOT/name;out.mkdir(exist_ok=False)
    shutil.copy2(Path(__file__),out/'runner-snapshot.py')
    env=gym.make('CarRacing-v3',continuous=True,render_mode='rgb_array',max_episode_steps=limit)
    env.reset(seed=seed); game=env.unwrapped
    client=JevClient(max_calls=2*math.ceil(limit/HOLD),model=MODEL) if method=='NumericJev' else None
    action=[0.,0.];steps=0;score=0.;offroad=0;last_new=0;last_count=game.tile_visited_count
    actions=[];latencies=[];done=False;reason='time_limit';start=time.monotonic()
    track=np.array([(x[2],x[3]) for x in game.track]);np.save(out/'track.npy',track)
    track_hash=hashlib.sha256(track.tobytes()).hexdigest()
    video=imageio.get_writer(out/'replay.mp4',fps=10,codec='libx264',macro_block_size=1,quality=7)
    try:
        while steps<limit and not done:
            state=telemetry(game,action)
            t0=time.monotonic();trace=[]
            if client:
                action,trace=decode_action(client,{'rules':RULES,'telemetry':state},reverse)
            elif method=='geometry-reference':action=reference_action(state)
            else:action=[0.,.2]
            latency=time.monotonic()-t0;latencies.append(latency)
            row={'step':steps,'telemetry':state,'command':list(action),'latency_s':latency,'trace':trace}
            steer,accel=action
            physical=np.array([steer,max(accel,0),max(-accel,0)],dtype=np.float32)
            for _ in range(HOLD):
                _,reward,terminated,truncated,info=env.step(physical)
                score+=float(reward);steps+=1
                offroad+=int(not any(w.tiles for w in game.car.wheels))
                if game.tile_visited_count>last_count:
                    last_count=game.tile_visited_count;last_new=steps
                if steps%5==0:
                    video.append_data(annotate(env.render(),method,steps,game,score,action))
                if terminated or truncated:
                    reason='lap_finished' if info.get('lap_finished') else ('out_of_playfield' if terminated else 'time_limit')
                    done=True;break
                if steps-last_new>=STALL_STEPS:
                    reason='no_new_tiles_for_10_sim_seconds';done=True;break
            row.update(visited_tiles=game.tile_visited_count,reward_total=score)
            actions.append(row)
            with (out/'actions.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
            if len(actions)%20==0:
                print(json.dumps({'run':name,'decisions':len(actions),'sim_seconds':steps/FPS,'coverage_percent':round(100*game.tile_visited_count/len(game.track),2),'score':round(score,2),'action':action}),flush=True)
            if time.monotonic()-start>900:
                reason='900_second_wall_time_limit';break
    finally:
        video.close()
        if client:
            (out/'api-records.json').write_text(json.dumps(client.records,indent=2));client.close()
    summary={'method':method,'seed':seed,'reverse_options':reverse,'environment':'CarRacing-v3','gymnasium_version':gym.__version__,'state_access':'privileged simulator telemetry and future centerline waypoints, not pixels','model':MODEL if client else None,'trained':False,'track_sha256':track_hash,'total_track_tiles':len(game.track),'visited_tiles':game.tile_visited_count,'coverage_percent':100*game.tile_visited_count/len(game.track),'reward':score,'steps':steps,'sim_seconds':steps/FPS,'fully_offroad_frame_percent':100*offroad/max(1,steps),'stop_reason':reason,'decision_count':len(actions),'api_calls':client.calls if client else 0,'mean_action_latency_s':float(np.mean(latencies)),'p95_action_latency_s':float(np.percentile(latencies,95)),'wall_seconds':time.monotonic()-start,'video':str(out/'replay.mp4')}
    Image.fromarray(annotate(env.render(),method,steps,game,score,action)).save(out/'final.png')
    env.close();(out/'summary.json').write_text(json.dumps(summary,indent=2))
    print('RESULT '+json.dumps(summary),flush=True)
    return summary


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--method',choices=['NumericJev','geometry-reference','straight-throttle'],required=True);parser.add_argument('--seed',type=int,default=7);parser.add_argument('--reverse',action='store_true');parser.add_argument('--limit',type=int,default=MAX_STEPS)
    args=parser.parse_args();credentials();play(args.method,args.seed,args.reverse,args.limit)
