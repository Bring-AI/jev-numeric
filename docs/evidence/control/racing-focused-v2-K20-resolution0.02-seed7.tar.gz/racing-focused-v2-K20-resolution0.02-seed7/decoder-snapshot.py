"""Batched finite-grid NumericJev decoder with configurable branching/precision."""
from decimal import Decimal


def decode(client, state, *, branching, resolution, reverse=False):
    step = Decimal(str(resolution));size = Decimal(2)/step
    if not 2 <= branching <= 100 or size != size.to_integral_value() or step <= 0:
        raise ValueError('Require integer grid size and branching in [2,100]')
    windows = {name:(0,int(size)) for name in ('steering','signed_acceleration')}
    trace=[]
    descriptions={'steering':'steering command in [-1,1), negative LEFT and positive RIGHT',
                  'signed_acceleration':'signed acceleration command in [-1,1), negative BRAKE and positive THROTTLE'}
    while any(hi-lo>1 for lo,hi in windows.values()):
        questions={};partitions={}
        for name,(lo,hi) in windows.items():
            if hi-lo==1:continue
            n=min(branching,hi-lo);cuts=[lo+(hi-lo)*i//n for i in range(n+1)];partitions[name]=cuts
            def value(i):return str(Decimal(-1)+step*i)
            criteria={str(i):f'{value(cuts[i])} <= {name} < {value(cuts[i+1])}' for i in range(n)}
            final=hi-lo<=branching
            instructions=state['rules']+'\n\n'+f'Choose the best {descriptions[name]} for the next 0.20 seconds of driving under the given rules and telemetry. Select the interval containing your intended command; bounds are lower-inclusive and upper-exclusive. Labels identify intervals, not command values. At the final level the lower endpoint will be executed.'
            if final:
                instructions+=' These final options show exact controls that will be executed.'
                for key in criteria:
                    val=value(cuts[int(key)]);v=float(val)
                    if name=='signed_acceleration':effect=f'BRAKE {abs(Decimal(val))}' if v<0 else f'THROTTLE {val}' if v>0 else 'COAST; no throttle or brake; cannot start moving'
                    else:effect='LEFT' if v<0 else 'RIGHT' if v>0 else 'STRAIGHT'
                    criteria[key]=f'Execute {name}={val}: {effect}.'
            if reverse:criteria=dict(reversed(list(criteria.items())))
            questions[name]={'type':'choice','instructions':instructions,'criteria':criteria}
        answers=client.ask(state,questions)['answers']
        for name,answer in answers.items():
            i=int(answer['choice']);cuts=partitions[name];windows[name]=(cuts[i],cuts[i+1])
        trace.append({'windows':dict(windows),'answers':answers})
    return [float(Decimal(-1)+step*windows[name][0]) for name in ('steering','signed_acceleration')],trace
