"""Prompt-only racing follow-up; simulator and selected numeric actions unchanged."""
import argparse
import copy
import importlib.util
import json
from pathlib import Path
import shutil
import sys

HERE=Path(__file__).resolve().parent
EXPERIMENTS=HERE.parents[1]
def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m)
    return m
r=module('base_racing',EXPERIMENTS/'car-racing-20260923/run.py')
d=module('numeric_decoder',EXPERIMENTS/'multigame-20260924/racing/decoder.py')

COMMON='''Drive forward to complete every road tile. Outputs are absolute steering and signed pedal controls, held for 0.20 seconds. There is no fallback controller. Current telemetry is expressed relative to the car, with positive right. Use the CURRENT state, not historical controls. Every question below specifies how to determine its own numerical control. Labels name numeric intervals, not the command itself. At a final singleton the stated exact lower endpoint is executed.'''
STEERING='''Determine ONLY the steering command, not the throttle or a target angle. Positive steering turns RIGHT, negative LEFT. Find the future_centerline_waypoints entry with tiles_ahead=4. Its bearing_right_degrees is b. A useful numerical steering guide is b/75, clipped to [-0.60,+0.60]. For example b=+30 means roughly +0.40 RIGHT; b=-15 means -0.20 LEFT; b=+6 means +0.08 RIGHT; b=0 means0. Current bearing has priority over the sign of past controls or the distant road tangent. If the point is behind the car, turn strongly toward its signed side, near +/-0.60, to recover. Use b, never copy road coordinates or an old steering command. Select the interval containing this numerical steering amount, even when the interval's categorical key is a different number.'''
PEDAL='''Determine ONLY signed pedal. Positive is THROTTLE, negative is BRAKE, zero is coasting. Read current speed v. Use gentle low-speed driving: if v<8 choose +0.08 throttle; if 8<=v<12 choose +0.04 throttle; if 12<=v<=14 choose0 coasting; if v>14 choose -0.02 gentle brake. When wheels_touching_road<4 or the absolute bearing of the tiles_ahead=4 waypoint exceeds35 degrees, target lower speed: v<5 choose+0.06; 5<=v<8 choose+0.02; 8<=v<=10 choose0; v>10 choose-0.02. Even offroad, keep positive throttle below5. Brake0.10 is too strong and may stop the car; use only the gentle magnitudes above. Compute the current case afresh: previous actions are not instructions.'''

def prepare(state,variant):
    state=copy.deepcopy(state)
    state['rules']=COMMON
    if variant!='history-v2':
        for name in ['recent_controls_oldest_first','previous_commands','stationary_duration_s']:
            state['telemetry'].pop(name,None)
    return state

def decode(client,state,branching,resolution,reverse,variant):
    if variant=='history-v2':
        # Probe the old exact policy with its recorded history as a control.
        return d.decode(client,state,branching=branching,resolution=resolution,reverse=reverse)
    state=prepare(state,variant)
    class Focused:
        def ask(self,st,questions):
            questions=copy.deepcopy(questions)
            for name,q in questions.items():
                q['instructions']=COMMON+'\n\n'+(STEERING if name=='steering' else PEDAL)
                q['instructions']+='\nBounds are lower-inclusive and upper-exclusive. Keep refining your intended numeric control; execute only the final grid lower endpoint.'
            return client.ask(st,questions)
    return d.decode(Focused(),state,branching=branching,resolution=resolution,reverse=reverse)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--seed',type=int,default=7)
    parser.add_argument('--branching',type=int,default=20)
    parser.add_argument('--resolution',default='0.02')
    parser.add_argument('--variant',default='focused-v2')
    parser.add_argument('--reverse',action='store_true')
    parser.add_argument('--probe',action='store_true')
    args=parser.parse_args();r.credentials()
    if args.probe:
        source=EXPERIMENTS/'multigame-20260924/racing/K20-resolution0.02/NumericJev-seed7'
        records=json.loads((source/'api-records.json').read_text())
        rows=[json.loads(x) for x in (source/'actions.jsonl').read_text().splitlines()]
        out=HERE/'probes.json'; results=[]
        with r.JevClient(max_calls=80,model=r.MODEL) as client:
            for i in [0,90,114,160,165]:
                state=records[2*i]['request']['state']
                for variant in ['history-v2','focused-v2']:
                    start=len(client.records)
                    a,t=decode(client,state,args.branching,args.resolution,False,variant)
                    row={'source_control':i,'variant':variant,'old_action':rows[i]['command'],'action':a,'trace':t,'records':client.records[start:]}
                    results.append(row)
                    print(json.dumps({k:v for k,v in row.items() if k not in ['records','trace']}),flush=True)
        out.write_text(json.dumps(results,indent=2));return
    r.ROOT=HERE/f'{args.variant}-K{args.branching}-resolution{args.resolution}'
    r.ROOT.mkdir(exist_ok=True)
    r.RULES=COMMON;r.STALL_STEPS=9001
    original_client=r.JevClient
    def client(**kw):
        kw['max_calls']=2700
        return original_client(**kw)
    r.JevClient=client
    r.decode_action=lambda c,s,reverse=False:decode(c,s,args.branching,args.resolution,reverse,args.variant)
    summary=r.play('NumericJev',args.seed,args.reverse,9000)
    out=Path(summary['video']).parent
    shutil.copy2(__file__,out/'prompt-runner-snapshot.py')
    shutil.copy2(EXPERIMENTS/'multigame-20260924/racing/decoder.py',out/'decoder-snapshot.py')
    (out/'rules.txt').write_text(COMMON+'\n\nSTEERING\n'+STEERING+'\n\nPEDAL\n'+PEDAL)
    summary.update(id=out.parent.name+'-'+out.name,variant=args.variant,branching=args.branching,resolution=args.resolution,
        no_new_tiles_guard=False,sim_time_limit_s=180,executed_action_overrides=0,
        success=summary['stop_reason']=='lap_finished',guidance='Explicit numerical steering/speed guidance in each question; previous action history removed from the model input. Jev computes and chooses the actual commands.')
    (out/'summary.json').write_text(json.dumps(summary,indent=2))

if __name__=='__main__':main()
