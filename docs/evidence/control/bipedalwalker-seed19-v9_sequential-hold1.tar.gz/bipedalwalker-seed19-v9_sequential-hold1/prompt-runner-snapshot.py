"""Sequential Jev gait case, knee memory, and motor selections. No computed motor targets."""
import importlib.util,json,argparse,shutil
spec=importlib.util.spec_from_file_location('w','/data/yww/notebook/numericjev-game-experiments/prompt-recovery-20260924/bipedalwalker/run_walker.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w);b=w.b
class Sequential(w.Controller):
 def __init__(self,variant):super().__init__(variant);self.p=1;self.m=0;self.k=.1
 def decode(self,client,config,state,reverse,path):
  o=state['observation']
  if self.variant in ('v10_rounded','v11_pure_arithmetic'):
   o=json.loads(json.dumps(o),parse_float=lambda x:round(float(x),3))
  m=self.m;u=1-m;p=self.p;k=self.k;ml=o[f'leg{m}'];ul=o[f'leg{u}'];vx=o['vx_scaled'];prior={'phase':p,'moving_leg':m,'knee_memory':k}
  status=f"Previous phase={p} (1 SWING,2 LOWER,3 PUSH), moving leg={m}, supporting leg={u}. Current support hip={ul['hip_angle']}, moving foot contact={ml['ground_contact']}, support knee={ul['knee_angle_plus1']}, vx={vx}. "
  rules='''Choose the gait action-case by applying these conditions exactly. If previous phase1 and support hip>=0.10: SWING. If previous phase1 and support hip<0.10, or previous phase2: enter LOWER. In LOWER, if moving foot contact=0 choose LOWER; if contact=1 choose LOWER_PUSH, preserving the hip-lowering goal while pushing. If previous phase3 choose PUSH. For LOWER_PUSH or PUSH only: if support knee>0.88 OR vx>0.348, append SWITCH; otherwise keep same moving leg. SWITCH changes next-step memory, not current action goals. Do not switch just because one foot touched. Conditions are on the raw values listed above.'''
  kinds=['SWING','LOWER','LOWER_PUSH','LOWER_PUSH_SWITCH','PUSH','PUSH_SWITCH']
  q={'gait_case':{'type':'choice','instructions':status+rules,'criteria':{str(i):kind+f' moving leg{m}, supporting leg{u}'+(f'; after this action next moving leg{u}' if 'SWITCH' in kind else '') for i,kind in enumerate(kinds)}}}
  r=self.ask(client,{'task':'Choose gait case before motor questions'},q,path,'sequential_gait_case');kind=kinds[int(r['answers']['gait_case']['choice'])]
  if kind=='SWING':self.p=1
  elif kind=='LOWER':self.p=2
  elif 'SWITCH' in kind:self.p=1;self.m=u
  else:self.p=3
  if kind.startswith('LOWER_PUSH'):krule=f'Updated support knee memory k=min({ml["knee_angle_plus1"]},0.1).'
  elif p==1:krule=f'Updated support knee memory k=min(0.1,{k}+0.03+(0.03 if {vx}>0.29 else0)).'
  else:krule=f'Preserve memory exactly: k={k}. No update.'
  left,right=0,180
  for depth in range(2):
   cuts=b.partitions(left,right);qs={'knee_memory':{'type':'choice','instructions':krule+' Choose interval for k. This is target-angle memory, not torque.','criteria':{str(j):f'{-.7+.005*cuts[j]:.3f} <= k < {-.7+.005*cuts[j+1]:.3f}' for j in range(len(cuts)-1)}}}
   rr=self.ask(client,{'model_chosen_gait_case':kind},qs,path,'sequential_knee_memory');j=int(rr['answers']['knee_memory']['choice']);left,right=cuts[j:j+2]
  self.k=round(-.7+.005*left,3)
  goals={f'leg{u}_hip':None,f'leg{m}_hip':1.1 if kind=='SWING' else .1 if kind.startswith('LOWER') else None,f'leg{m}_knee':-.6 if kind=='SWING' else .1 if kind=='LOWER' else self.k,f'leg{u}_knee':self.k if kind in ('SWING','LOWER') else 1.}
  trace=[{'previous_model_memory':prior,'model_chosen_gait_case':kind,'next_model_memory':{'phase':self.p,'moving_leg':self.m,'knee_memory':self.k},'disclosed_angle_goal_template':goals}];windows={n:(0,400) for n in config['names']}
  for depth in range(2):
   qs={};cb={}
   for name,(lo,hi) in windows.items():
    i=int(name[3]);joint=name.split('_')[1];l=o[f'leg{i}'];goal=goals[name];cuts=b.partitions(lo,hi);cb[name]=cuts
    if joint=='hip':expr=(f'0.495*({goal}-({l["hip_angle"]}))-0.1375*({l["hip_speed"]})+' if goal is not None else '')+f'0.495*({o["torso_angle"]})+0.825*({o["torso_angular_velocity_scaled"]})'
    else:expr=f'2.2*({goal}-({l["knee_angle_plus1"]}))-0.1375*({l["knee_speed"]})-8.25*({o["vy_scaled"]})'
    ins=f'Compute motor torque {name} from {expr}. Clamp result to [-1,0.995]. Select interval containing the result. The gait case {kind} was already chosen by you; angle goal {goal} is a fixed template value or your chosen knee memory. Do not use that angle goal as motor torque. Subtraction of negative is addition.'
    if self.variant=='v10_sequential_cases':
     angle=l['hip_angle'] if joint=='hip' else l['knee_angle_plus1'];speed=l['hip_speed'] if joint=='hip' else l['knee_speed']
     ins+=f' Current angle={angle}, target={goal}, speed={speed}. Target above current angle means POSITIVE feedback; target below current angle means NEGATIVE feedback. Speed damping opposes joint motion. Downward torso speed adds positive knee feedback. Use balance correction when no hip target.'
    if self.variant=='v11_pure_arithmetic':ins=f'Evaluate ({expr}). Clamp the number to [-1,0.995]. Select the numerical interval containing that result. Subtracting a negative is addition. Bounds are lower inclusive.'
    qs[name]={'type':'choice','instructions':ins,'criteria':{str(j):f'{b.grid_value(cuts[j])} <= torque < {b.grid_value(cuts[j+1])}' for j in range(len(cuts)-1)}}
   r=self.ask(client,{'task':'Calculate each focused motor equation; no previous motor commands'},qs,path,'motor_interval')
   for n,a in r['answers'].items():j=int(a['choice']);windows[n]=(cb[n][j],cb[n][j+1])
   trace.append({'depth':depth,'windows':dict(windows),'choices':{n:a['choice'] for n,a in r['answers'].items()}})
  return [float(b.LOW+b.RESOLUTION*windows[n][0]) for n in config['names']],trace
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--variant',default='v9_sequential');p.add_argument('--seed',type=int,default=7);p.add_argument('--hold',type=int,default=1);args=p.parse_args();b.credentials();b.CONFIG['bipedalwalker'].update(rules=w.RULES+' Sequential gait cases preserve chained reference transitions and hip goals. Model selects gait then knee memory then actual motor torques.',hold=args.hold,guidance='Sequential Jev gait case, disclosed phase-to-angle-goal templates, Jev numeric knee memory, then NumericJev PD torque selection. Public heuristic with gain1.1; no Python motor computation.')
 ctl=Sequential(args.variant);b.decode_action=ctl.decode;old=b.JevClient;b.JevClient=lambda **kw:old(**dict(kw,max_calls=8200));a=args.variant+f'-hold{args.hold}';summary=b.play('bipedalwalker',args.seed,attempt=a,wall_limit=3600);out=w.ROOT/summary['id'];shutil.copy2(__file__,out/'prompt-runner-snapshot.py');shutil.copy2(w.__file__,out/'imported-walker-runner.py');summary['intermediate_gait_protocol']='Five sequential API calls per motor decision: gait case1, knee-memory numerical refinement2, four motor numerical refinements2. Templates choose ANGLE goals only; actual torques all model-selected. Controlfrequency hold1.';(out/'summary.json').write_text(json.dumps(summary,indent=2))
