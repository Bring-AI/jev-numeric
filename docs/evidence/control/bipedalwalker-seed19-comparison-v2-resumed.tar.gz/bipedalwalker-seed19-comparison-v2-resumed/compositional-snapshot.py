"""Model-decoded signed contributions with explicit, auditable linear composition.

No arithmetic expression is evaluated here. Jev selects every numerical term;
the only numerical postprocessing is summing selected integer grid units and
clipping the resulting physical command. Correct answers belong only in probes.
"""
from decimal import Decimal
import json
import time

STEP = Decimal('.005')
OFFSET = 3200
COUNT = 2 * OFFSET + 1
COEFFICIENTS = (.495, 2.2, .1375, .495, .825, 8.25)


def number(value):
    return format(Decimal(str(value)), 'f')


def boundary(index):
    return STEP * (index - OFFSET) - STEP / 2


def ask_logged(client, state, questions, log_path, kind):
    started = time.monotonic()
    response = client.ask(state, questions)
    if log_path is not None:
        with log_path.open('a') as file:
            file.write(json.dumps({'kind': kind, 'request': {'model': client.model, 'state': state, 'questions': questions},
                                   'response': response, 'latency_s': time.monotonic() - started}) + '\n')
    return response


def decode_terms(client, expressions, log_path=None):
    windows = {name: (0, COUNT) for name in expressions}
    trace = []
    while any(hi - lo > 1 for lo, hi in windows.values()):
        questions, partitions = {}, {}
        for name, (lo, hi) in windows.items():
            if hi - lo == 1:
                continue
            count = min(20, hi - lo)
            cuts = [lo + (hi - lo) * i // count for i in range(count + 1)]
            partitions[name] = cuts
            questions[name] = {
                'type': 'choice',
                'instructions': f'Calculate this single signed arithmetic term: {expressions[name]}. '
                                'Select the interval containing its numerical result. This is one contribution, NOT a whole motor command. '
                                'Do not clip at -1 or +1. Only clip outside [-16,16]. Subtracting a negative adds it. '
                                'The final interval center is the term readout; keep the same calculation at every refinement.',
                'criteria': {f'c{i:02d}': f'{number(boundary(cuts[i]))} <= number < {number(boundary(cuts[i+1]))}' for i in range(count)},
            }
        response = ask_logged(client, {'task': 'Compute independent signed arithmetic contributions.'}, questions, log_path, 'numeric_terms')
        for name in questions:
            key = response['answers'][name]['choice']
            assert key in questions[name]['criteria'], (name, key)
            i = int(key[1:])
            windows[name] = tuple(partitions[name][i:i+2])
        trace.append({'windows': dict(windows), 'choices': {name: response['answers'][name]['choice'] for name in questions}})
    return {name: lo - OFFSET for name, (lo, hi) in windows.items()}, trace


def compose_actions(units, components):
    return [float(STEP * max(-200, min(199, sum(units[name] for name in names)))) for names in components.values()]


def gait_from_answers(phase, moving, answers):
    if phase == 1 and not answers['behind']:
        return 'SWING', 1, moving
    if phase in (1, 2):
        if not answers['contact']:
            return 'LOWER', 2, moving
        kind = 'LOWER_PUSH'
    else:
        kind = 'PUSH'
    if answers['knee_high'] or answers['fast']:
        return kind + '_SWITCH', 1, 1 - moving
    return kind, 3, moving


def choose_gait(client, phase, moving, observation, log_path):
    support = observation[f'leg{1-moving}']
    moving_leg = observation[f'leg{moving}']
    comparisons = {
        'behind': (support['hip_angle'], '<', .10),
        'contact': (moving_leg['ground_contact'], '==', 1),
        'knee_high': (support['knee_angle_plus1'], '>', .88),
        'fast': (observation['vx_scaled'], '>', .348),
    }
    questions = {name: {'type': 'choice', 'instructions': f'Is the numerical statement {number(value)} {op} {number(threshold)} true? '
                        'Evaluate only this comparison. A strict inequality is false at equality.',
                        'criteria': {'yes': 'The displayed numerical statement is true.', 'no': 'The displayed numerical statement is false.'}}
                 for name, (value, op, threshold) in comparisons.items()}
    response = ask_logged(client, {'task': 'Independent numerical comparisons for gait transitions.'}, questions, log_path, 'gait_predicates')
    answers = {name: response['answers'][name]['choice'] == 'yes' for name in questions}
    assert all(response['answers'][name]['choice'] in ('yes', 'no') for name in questions)
    return gait_from_answers(phase, moving, answers), answers


def angle_goals(kind, moving, support_knee=0.):
    support = 1 - moving
    return {f'leg{moving}_hip': 1.1 if kind == 'SWING' else .1 if kind.startswith('LOWER') else None,
            f'leg{support}_hip': None,
            f'leg{moving}_knee': -.6 if kind == 'SWING' else .1 if kind == 'LOWER' else support_knee,
            f'leg{support}_knee': support_knee if kind in ('SWING', 'LOWER') else 1.}


def term_expressions(observation, goals, coefficients=COEFFICIENTS):
    hip_gain, knee_gain, damping, balance, rotation, vertical = coefficients
    o = observation
    expressions = {
        'body_balance': f'{number(balance)}*({number(o["torso_angle"])})',
        'body_rotation': f'{number(rotation)}*({number(o["torso_angular_velocity_scaled"])})',
        'body_vertical': f'-{number(vertical)}*({number(o["vy_scaled"])})',
    }
    components = {}
    for leg in (0, 1):
        raw = o[f'leg{leg}']
        for joint in ('hip', 'knee'):
            name = f'leg{leg}_{joint}'
            goal = goals[name]
            parts = []
            if goal is not None:
                measured = raw['hip_angle'] if joint == 'hip' else raw['knee_angle_plus1']
                gain = hip_gain if joint == 'hip' else knee_gain
                expressions[name + '_p'] = f'{number(gain)}*({number(goal)}-({number(measured)}))'
                expressions[name + '_d'] = f'-{number(damping)}*({number(raw[joint + "_speed"])})'
                parts.extend([name + '_p', name + '_d'])
            parts.extend(['body_balance', 'body_rotation'] if joint == 'hip' else ['body_vertical'])
            components[name] = parts
    return expressions, components
