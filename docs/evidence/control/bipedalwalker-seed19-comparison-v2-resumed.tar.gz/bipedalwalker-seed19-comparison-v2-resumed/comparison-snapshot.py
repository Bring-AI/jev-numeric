"""Fixed affine rules compiled to input intervals, with model-only bin selection.

Each descriptor defines y=slope*(observed_value-origin). Only fixed policy
constants enter the inverse thresholds; observed_value is never evaluated.
This is a disclosed comparison-table controller, not free arithmetic inference.
"""
from decimal import Decimal
from compositional import STEP, OFFSET, COUNT, COEFFICIENTS, boundary, number, ask_logged


def descriptors(observation, goals, coefficients=COEFFICIENTS):
    hp, kp, damp, balance, rotation, vertical = coefficients
    def d(value, slope, origin=0):
        return {'value': number(value), 'slope': number(slope), 'origin': number(origin)}
    terms = {
        'body_balance': d(observation['torso_angle'], balance),
        'body_rotation': d(observation['torso_angular_velocity_scaled'], rotation),
        'body_vertical': d(observation['vy_scaled'], -vertical),
    }
    components = {}
    for leg in (0, 1):
        raw = observation[f'leg{leg}']
        for joint in ('hip', 'knee'):
            name = f'leg{leg}_{joint}'
            goal = goals[name]
            parts = []
            if goal is not None:
                terms[name+'_p'] = d(raw['hip_angle' if joint == 'hip' else 'knee_angle_plus1'], -hp if joint == 'hip' else -kp, goal)
                terms[name+'_d'] = d(raw[joint+'_speed'], -damp)
                parts.extend([name+'_p', name+'_d'])
            parts.extend(['body_balance', 'body_rotation'] if joint == 'hip' else ['body_vertical'])
            components[name] = parts
    return terms, components


def threshold(value):
    # Input observations have six decimal places; twelve preserve finer edges.
    return format(value.quantize(Decimal('.000000000001')), 'f').rstrip('0').rstrip('.') or '0'


def intervals(descriptor, lo, hi):
    slope, origin = Decimal(descriptor['slope']), Decimal(descriptor['origin'])
    n = min(20, hi-lo)
    cuts = [lo+(hi-lo)*i//n for i in range(n+1)]
    parts = []
    for i in range(n):
        start, end = cuts[i:i+2]
        a, z = boundary(start)/slope+origin, boundary(end)/slope+origin
        if slope > 0:
            lower, upper = threshold(a), threshold(z)
            text = f'{lower} <= x < {upper}'
            if start == 0:
                text = f'x < {upper}'
            if end == COUNT:
                text = f'x >= {lower}'
        else:
            lower, upper = threshold(z), threshold(a)
            text = f'{lower} < x <= {upper}'
            if start == 0:
                text = f'x > {lower}'
            if end == COUNT:
                text = f'x <= {upper}'
        parts.append({'key': f'c{i:02d}', 'start': start, 'end': end,
                      'lower': lower, 'upper': upper, 'criterion': text})
    return parts


def decode_comparisons(client, terms, log_path=None):
    windows = {name: (0, COUNT) for name in terms}
    trace = []
    while any(hi-lo > 1 for lo, hi in windows.values()):
        questions, partitions = {}, {}
        for name, (lo, hi) in windows.items():
            if hi-lo == 1:
                continue
            parts = intervals(terms[name], lo, hi)
            partitions[name] = {p['key']: p for p in parts}
            # Present raw-observation intervals from low to high in both cases.
            ordered = parts if Decimal(terms[name]['slope']) > 0 else list(reversed(parts))
            questions[name] = {
                'type': 'choice',
                'instructions': f'The observed number x = {terms[name]["value"]}. Which numerical interval contains x? '
                                'Choose by comparing this number with the interval bounds. Pay attention to minus signs and decimal places. '
                                'Do not calculate a motor command; only locate x.',
                'criteria': {p['key']: p['criterion'] for p in ordered},
            }
        response = ask_logged(client, {'task': 'Locate each displayed observed number in its intervals.'}, questions, log_path, 'comparison_terms')
        choices = {}
        for name in questions:
            key = response['answers'][name]['choice']
            part = partitions[name][key]
            windows[name] = (part['start'], part['end'])
            choices[name] = key
        trace.append({'windows': dict(windows), 'choices': choices})
    return {name: lo-OFFSET for name, (lo, hi) in windows.items()}, trace
