"""Replay an exact recorded response prefix, then retry transport failures only."""
import json
from pathlib import Path
import time
import httpx


class ResumeTransport:
    def __init__(self, network, prefix, provenance, events):
        self.network = network
        self.prefix = prefix
        self.provenance = provenance
        self.events = events
        self.model = network.model
        self._http = network._http
        self.records = []
        self.index = 0

    @property
    def calls(self):
        return min(self.index, len(self.prefix)) + self.network.calls

    def ask(self, state, questions):
        payload = {'model': self.model, 'state': state, 'questions': questions}
        started = time.monotonic()
        if self.index < len(self.prefix):
            old = self.prefix[self.index]
            assert payload == old['request'], f'Resumed payload diverged at request {self.index}'
            response = old['response']
            origin = {'response_origin': 'recorded_prefix', 'source_request_index': self.index,
                      'source_model_latency_s': old['latency_s']}
        else:
            for attempt in range(6):
                try:
                    response = self.network.ask(state, questions)
                    break
                except (httpx.TransportError, RuntimeError) as exc:
                    retryable = isinstance(exc, httpx.TransportError) or any(f'HTTP {code};' in str(exc) for code in [429, 502, 503, 504])
                    with self.events.open('a') as file:
                        file.write(json.dumps({'request_index': self.index, 'attempt': attempt+1,
                                               'error_type': type(exc).__name__, 'retryable': retryable})+'\n')
                    if not retryable or attempt == 5:
                        raise
                    time.sleep(2**attempt)
            origin = {'response_origin': 'live_api', 'network_attempts_so_far': self.network.calls}
        self.records.append({'request': payload, 'response': response, **origin})
        with self.provenance.open('a') as file:
            file.write(json.dumps({'request_index': self.index, 'observed_resume_latency_s': time.monotonic()-started, **origin})+'\n')
        self.index += 1
        return response

    def close(self):
        self.network.close()
