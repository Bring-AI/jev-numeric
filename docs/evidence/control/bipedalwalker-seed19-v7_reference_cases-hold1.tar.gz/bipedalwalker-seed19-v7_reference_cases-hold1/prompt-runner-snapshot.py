"""Full model-evaluated reference gait. Every stored plan value and motor is Jev-selected."""
import importlib.util,json,argparse,shutil
from pathlib import Path
spec=importlib.util.spec_from_file_location('w','/data/yww/notebook/numericjev-game-experiments/prompt-recovery-20260924/bipedalwalker/run_walker.py');w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w);b=w.b
PROGRAM='''Evaluate this public Gymnasium-inspired gait program, in order, using prior model memory and present observation. Return the asked output. This stage chooses joint GOAL ANGLES and next memory, not motor commands.
Initialize hip_goal=[NONE,NONE], knee_goal=[NONE,NONE]. m is moving_leg, u=1-m, p is phase (1 SWING,2 LOWER,3 PUSH), k is supporting_knee memory.
IF p==1: hip_goal[m]=1.1; knee_goal[m]=-0.6; k=min(0.1,k+0.03+(0.03 if vx_scaled>0.29 else 0)); knee_goal[u]=k. If supporting hip angle<0.10 then p=2.
IF p==2: hip_goal[m]=0.1; knee_goal[m]=0.1; knee_goal[u]=k. If moving ground_contact=1 then p=3 and k=min(moving knee_angle_plus1,0.1).
IF p==3: knee_goal[m]=k; knee_goal[u]=1.0. If supporting knee_angle_plus1>0.88 OR vx_scaled>0.348 then p=1 and m=1-m (only update memory; keep goals already assigned).
The three IF blocks are sequential, so more than one can execute this decision. Hip goals assigned in earlier blocks remain assigned. An unchanged NONE hip receives torso-balance feedback only. Return goals after all blocks; return p,m,k as next memory. Do not confuse goal angles with motor torques.'''
class Full(w.Controller):
 def __init__(self,variant):super().__init__(variant);self.phase=1;self.moving=0;self.support=.1
 def decode(self,client,config,state,reverse,path):
  o=state['observation'];prior={'phase':self.phase,'moving_leg':self.moving,'supporting_knee':self.support};s={'previous_model_memory':prior,'current_observation':o}
  codes=[(p,m) for m in (0,1) for p in (1,2,3)]
  hipopts=['NONE','0.1','1.1'];kneeopts=['-0.6','0.1','1.0','NEW_K_MEMORY','OLD_K_MEMORY']
  qs={'next_memory_phase':{'type':'choice','instructions':PROGRAM+' Return next p and m after all three IF blocks.','criteria':{str(i):f'next p={p}, moving_leg={m}' for i,(p,m) in enumerate(codes)}}}
  for i in (0,1):
   qs[f'leg{i}_hip_goal']={'type':'choice','instructions':PROGRAM+f' Return final hip_goal[{i}].','criteria':{str(j):v for j,v in enumerate(hipopts)}}
   qs[f'leg{i}_knee_goal']={'type':'choice','instructions':PROGRAM+f' Return final knee_goal[{i}]. NEW_K_MEMORY is updated k from this step; OLD_K_MEMORY is incoming k.','criteria':{str(j):v for j,v in enumerate(kneeopts)}}
  cuts=b.partitions(0,180)
  qs['support_knee_memory']={'type':'choice','instructions':PROGRAM+' Return updated numeric k. Select its interval.','criteria':{str(i):f'{-.7+.005*cuts[i]:.3f} <= k < {-.7+.005*cuts[i+1]:.3f}' for i in range(len(cuts)-1)}}
  if self.variant=='v8_focused_reference':
   m=self.moving;u=1-m;ml=o[f'leg{m}'];ul=o[f'leg{u}'];vx=o['vx_scaled'];p=self.phase;k=self.support
   status=f"Current phase={p}; moving leg={m}; support leg={u}. Support hip={ul['hip_angle']}; moving foot contact={ml['ground_contact']}; support knee={ul['knee_angle_plus1']}; vx={vx}; old knee memory={k}; moving knee={ml['knee_angle_plus1']}. "
   if p==3:
    phase_rule=f"If support knee {ul['knee_angle_plus1']}>0.88 OR vx {vx}>0.348, next p=1 and moving leg={u}; otherwise next p=3 and moving leg={m}."
    memory_rule=f"Preserve memory exactly: k={k}. No update occurs in phase3."
   elif p==2:
    phase_rule=f"If moving contact {ml['ground_contact']}=0, next p=2,m={m}. If contact=1, enter p3; then if support knee>0.88 OR vx>0.348 next p=1,m={u}, otherwise p=3,m={m}."
    memory_rule=f"If moving contact={ml['ground_contact']} is1, k=min({ml['knee_angle_plus1']},0.1). Otherwise preserve k={k}."
   else:
    phase_rule=f"If support hip {ul['hip_angle']}>=0.1 keep p=1,m={m}. Otherwise enter p2; if moving contact=0 keep p2,m={m}; if contact=1 enter p3 then if support knee>0.88 OR vx>0.348 choose p1,m={u}, else p3,m={m}."
    memory_rule=f"First k=min(0.1,{k}+0.03+(0.03 if vx {vx}>0.29 else0)). If support hip {ul['hip_angle']}<0.1 AND moving contact {ml['ground_contact']}=1 then override k=min({ml['knee_angle_plus1']},0.1)."
   qs['next_memory_phase']['instructions']=status+phase_rule+' Return next p and moving leg.'
   qs['support_knee_memory']['instructions']=status+memory_rule+' Choose interval for k; this is model memory.'
   for i in (0,1):
    if p==3:hr='NONE';kr='OLD_K_MEMORY' if i==m else '1.0'
    elif p==2:
     hr='0.1' if i==m else 'NONE'
     kr=("NEW_K_MEMORY if moving contact=1, otherwise0.1" if i==m else "1.0 if moving contact=1, otherwise OLD_K_MEMORY")
    else:
     hr=('0.1 if support hip<0.1, otherwise1.1' if i==m else 'NONE')
     kr=("-0.6 if support hip>=0.1; otherwise0.1 if moving contact=0; otherwise NEW_K_MEMORY" if i==m else "1.0 if support hip<0.1 AND moving contact=1; otherwise NEW_K_MEMORY")
    qs[f'leg{i}_hip_goal']['instructions']=status+f'For leg{i} hip goal choose: '+hr+'. Return joint angle goal, not motor torque.'
    qs[f'leg{i}_knee_goal']['instructions']=status+f'For leg{i} knee goal choose: '+kr+'. Return joint angle goal, not motor torque.'
  r=self.ask(client,s,qs,path,'model_reference_plan');ans=r['answers'];pi=int(ans['next_memory_phase']['choice']);self.phase,self.moving=codes[pi]
  j=int(ans['support_knee_memory']['choice']);left,right=cuts[j:j+2];fine=b.partitions(left,right)
  q={'support_knee_memory':{'type':'choice','instructions':PROGRAM+' Refine the chosen numeric k interval; return updated k.','criteria':{str(i):f'{-.7+.005*fine[i]:.3f} <= k < {-.7+.005*fine[i+1]:.3f}' for i in range(len(fine)-1)}}}
  if self.variant=='v8_focused_reference': q['support_knee_memory']['instructions']=status+memory_rule+' Refine k within the selected interval.'
  rr=self.ask(client,s,q,path,'model_reference_memory_refine');self.support=round(-.7+.005*fine[int(rr['answers']['support_knee_memory']['choice'])],3)
  goals={}
  for i in (0,1):
   ht=hipopts[int(ans[f'leg{i}_hip_goal']['choice'])];kt=kneeopts[int(ans[f'leg{i}_knee_goal']['choice'])]
   goals[f'leg{i}_hip']=None if ht=='NONE' else float(ht)
   goals[f'leg{i}_knee']=self.support if kt=='NEW_K_MEMORY' else prior['supporting_knee'] if kt=='OLD_K_MEMORY' else float(kt)
  trace=[{'previous_model_memory':prior,'new_model_memory':{'phase':self.phase,'moving_leg':self.moving,'supporting_knee':self.support},'model_selected_joint_goals':goals}];windows={n:(0,400) for n in config['names']}
  for depth in range(2):
   qs={};cb={}
   for name,(lo,hi) in windows.items():
    i=int(name[3]);joint=name.split('_')[1];l=o[f'leg{i}'];goal=goals[name];c=b.partitions(lo,hi);cb[name]=c
    if joint=='hip':expr=(f'0.495*({goal}-({l["hip_angle"]}))-0.1375*({l["hip_speed"]})+' if goal is not None else '')+f'0.495*({o["torso_angle"]})+0.825*({o["torso_angular_velocity_scaled"]})'
    else:expr=f'2.2*({goal}-({l["knee_angle_plus1"]}))-0.1375*({l["knee_speed"]})-8.25*({o["vy_scaled"]})'
    ins=f'Calculate MOTOR TORQUE for {name}: {expr}. Clamp result to [-1,0.995]. Select interval containing the answer. This is PD feedback; do not copy the target angle as a command. Subtracting a negative means adding.'
    if self.variant=='v7_reference_cases':
     ins+=f' Current joint angle={l["hip_angle"] if joint=="hip" else l["knee_angle_plus1"]}, target={goal}. Negative torque decreases angle; positive increases it. Torso correction has same sign as torso angle/rotation. Negative vertical speed adds POSITIVE knee extension correction. Choose zero/small torque near balance, use high torque only for large error.'
    qs[name]={'type':'choice','instructions':ins,'criteria':{str(j):f'{b.grid_value(c[j])} <= motor < {b.grid_value(c[j+1])}' for j in range(len(c)-1)}}
   r=self.ask(client,{'simulation_step':state['simulation_step'],'task':'Use the per-motor equation; raw observations and model-chosen goals are directly substituted, no command has been computed.'},qs,path,'motor_interval')
   for n,a in r['answers'].items():j=int(a['choice']);windows[n]=(cb[n][j],cb[n][j+1])
   trace.append({'depth':depth,'windows':dict(windows),'choices':{n:a['choice'] for n,a in r['answers'].items()}})
  return [float(b.LOW+b.RESOLUTION*windows[n][0]) for n in config['names']],trace
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--variant',default='v6_reference');p.add_argument('--seed',type=int,default=7);p.add_argument('--hold',type=int,default=1);args=p.parse_args();b.credentials();b.CONFIG['bipedalwalker'].update(rules=w.RULES+'\n'+PROGRAM,hold=args.hold,guidance='Full public Gymnasium reference gait evaluated by Jev as explicit planning choices, model-selected goals and dynamic knee memory; then NumericJev direct PD motor choices with gain1.1.')
 ctl=Full(args.variant);b.decode_action=ctl.decode;old=b.JevClient;b.JevClient=lambda **kw:old(**dict(kw,max_calls=6500));a=args.variant+f'-hold{args.hold}';summary=b.play('bipedalwalker',args.seed,attempt=a,wall_limit=3600);out=w.ROOT/summary['id'];shutil.copy2(__file__,out/'prompt-runner-snapshot.py');shutil.copy2(w.__file__,out/'imported-walker-runner.py');summary['intermediate_gait_protocol']='Four API calls per motor decision: Jev selects next gait memory, all four joint angle goals, and numeric support-knee memory in2calls;2calls choose motor intervals. Model memory only. Hold1 changes control frequency.';(out/'summary.json').write_text(json.dumps(summary,indent=2))
