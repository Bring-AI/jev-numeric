"""Live Jev prompt recovery. Intermediate gait is model-selected; all motors are NumericJev choices."""
import argparse,importlib.util,json,time,shutil
from pathlib import Path
spec=importlib.util.spec_from_file_location('base','/data/yww/notebook/numericjev-game-experiments/multigame-20260924/games/run_games.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
ROOT=Path(__file__).resolve().parent;b.ROOT=ROOT
PHASES=['SWING_LEG0','LOWER_LEG0','PUSH_LEG1','SWING_LEG1','LOWER_LEG1','PUSH_LEG0']
PHASE_RULES='''Select the current gait phase by updating previous_phase with the current observations. Start in SWING_LEG0. Phase cycle: SWING_LEG0 -> LOWER_LEG0 -> PUSH_LEG1 -> SWING_LEG1 -> LOWER_LEG1 -> PUSH_LEG0 -> SWING_LEG0.
SWING_LEG0: stay unless leg1 hip_angle <0.10, then LOWER_LEG0. LOWER_LEG0: stay unless leg0 ground_contact=1, then PUSH_LEG1. PUSH_LEG1: stay unless leg1 knee_angle_plus1>0.88 OR vx_scaled>0.348, then SWING_LEG1.
SWING_LEG1: stay unless leg0 hip_angle <0.10, then LOWER_LEG1. LOWER_LEG1: stay unless leg1 ground_contact=1, then PUSH_LEG0. PUSH_LEG0: stay unless leg0 knee_angle_plus1>0.88 OR vx_scaled>0.348, then SWING_LEG0.
Evaluate at most one transition each decision. This is gait state, not a motor command. Choose only according to these conditions. Current phase controls joint goals; never choose a phase because its label sounds good.'''
RULES='''Walk to right terrain finish without torso contact. Motor commands set sign of motor speed and fraction of torque. Positive increases joint angle; negative decreases it. Hip angle bounds -0.8..1.1; knee observation=joint angle+1 with bounds -0.6..0.9. Commands are held for stated frames. A joint goal is an angle, NOT a motor command: motor uses proportional goal-minus-measurement and velocity damping. The model separately chooses its six-state gait phase, then chooses all four motor commands via K20 numerical interval refinement at0.005. Python renders phase-dependent constant goals and raw measurements in disclosed PD formulas; Python never computes or substitutes a motor answer. Past motor commands are omitted to avoid anchoring. Torso and joint speeds are the native Gymnasium scaled observations.'''
class Controller:
 def __init__(self,variant):self.variant=variant;self.phase='SWING_LEG0'
 def ask(self,client,state,questions,path,kind):
  t=time.monotonic();response=client.ask(state,questions)
  with path.open('a') as f:f.write(json.dumps({'kind':kind,'request':{'model':b.MODEL,'state':state,'questions':questions},'response':response,'latency_s':time.monotonic()-t})+'\n')
  return response
 def decode(self,client,config,state,reverse,path):
  obs=state['observation'];step=state['simulation_step'];trace=[]
  previous=self.phase
  phaseq={'gait_phase':{'type':'choice','instructions':PHASE_RULES,'criteria':{str(i):x for i,x in enumerate(PHASES)}}}
  resp=self.ask(client,{'previous_phase':previous,'observation':obs},phaseq,path,'model_gait_phase')
  self.phase=PHASES[int(resp['answers']['gait_phase']['choice'])]
  trace.append({'model_selected_phase':self.phase,'previous_phase':previous})
  phasei=PHASES.index(self.phase);moving=0 if phasei<3 else 1;support=1-moving;kind=phasei%3
  goals={f'leg{moving}_hip':1.1 if kind==0 else (.1 if kind==1 else None),f'leg{support}_hip':None,f'leg{moving}_knee':-.6 if kind==0 else .1,f'leg{support}_knee':1.0 if kind==2 else .1}
  windows={n:(0,400) for n in config['names']}
  for depth in range(2):
   qs={};cuts_by={}
   for name,(lo,hi) in windows.items():
    i=int(name[3]);joint=name.split('_')[1];leg=obs[f'leg{i}'];goal=goals[name];cuts=b.partitions(lo,hi);cuts_by[name]=cuts
    hg,kg,hd,kd,bal,ang,vert=(.45,2,.125,.125,.45,.75,7.5)
    if self.variant in ('v4_tuned','v5_tuned_verbal'):hg,kg,hd,kd,bal,ang,vert=(.6,1.5,.375,.5,.75,1.5,7.5)
    if joint=='hip':
     expr=(f'{hg}*({goal}-({leg["hip_angle"]}))-{hd}*({leg["hip_speed"]})+' if goal is not None else '')+f'{bal}*({obs["torso_angle"]})+{ang}*({obs["torso_angular_velocity_scaled"]})'
    else:expr=f'{kg}*({goal}-({leg["knee_angle_plus1"]}))-{kd}*({leg["knee_speed"]})-{vert}*({obs["vy_scaled"]})'
    instruction=f'You select {name} motor torque. Current gait phase={self.phase}. Calculate this exact expression: {expr}. Clamp result to [-1,0.995]. Choose the numeric interval containing that computed result. Parentheses enclose raw signed measurements. Subtracting a negative is addition. Motor command is NOT target angle. At the fine refinement choose the best value in the already selected coarse interval; final lower bound is executed.'
    if self.variant in ('v3_verbal','v5_tuned_verbal'):
     measured=leg['hip_angle'] if joint=='hip' else leg['knee_angle_plus1'];velocity=leg['hip_speed'] if joint=='hip' else leg['knee_speed']
     instruction+=f' Current joint angle={measured}, joint speed={velocity}, target angle={goal}. If current angle exceeds target, use NEGATIVE angle-error correction; if below target, POSITIVE. Joint speed damping opposes its sign. Positive knee extends; negative knee bends. Downward vertical speed means positive knee correction. For untracked support hip use only torso balance terms.'
    criteria={str(j):f'{b.grid_value(cuts[j])} <= {name} < {b.grid_value(cuts[j+1])}' for j in range(len(cuts)-1)}
    if self.variant in ('v3_verbal','v5_tuned_verbal'):
     for j in range(len(cuts)-1):criteria[str(j)]+=('; NEGATIVE motor, decrease angle' if cuts[j+1]<=200 else '; POSITIVE motor, increase angle' if cuts[j]>200 else '; zero or positive motor')
    qs[name]={'type':'choice','instructions':instruction,'criteria':criteria}
   resp=self.ask(client,{'task':'Execute the arithmetic motor feedback instruction. All measurements appear directly in each question.','simulation_step':step,'action_hold_frames':config['hold']},qs,path,'motor_interval')
   for name,answer in resp['answers'].items():j=int(answer['choice']);windows[name]=(cuts_by[name][j],cuts_by[name][j+1])
   trace.append({'depth':depth,'windows':dict(windows),'choices':{n:a['choice'] for n,a in resp['answers'].items()}})
  return [float(b.LOW+b.RESOLUTION*windows[n][0]) for n in config['names']],trace
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--variant',default='v2_literal');p.add_argument('--seed',type=int,default=7);p.add_argument('--hold',type=int,default=5);p.add_argument('--wall-limit',type=int,default=1800);args=p.parse_args()
 b.credentials();c=b.CONFIG['bipedalwalker'];c.update(rules=RULES+'\n'+PHASE_RULES,guidance='Explicit public-heuristic inspired six-state gait chosen by Jev, then per-joint raw-value PD expression chosen by NumericJev. No Python motor target or replacement.',hold=args.hold)
 ctl=Controller(args.variant);b.decode_action=ctl.decode
 # Additional model gait choice consumes one API call per motor decision.
 OldClient=b.JevClient
 b.JevClient=lambda **kw:OldClient(**dict(kw,max_calls=2000))
 attempt=args.variant+(f'-hold{args.hold}' if args.hold!=5 else '')
 summary=b.play('bipedalwalker',args.seed,attempt=attempt,wall_limit=args.wall_limit)
 out=ROOT/summary['id'];shutil.copy2(__file__,out/'prompt-runner-snapshot.py');summary['intermediate_gait_protocol']='Jev choice among six gait states before four K20x2 motor queries, phase carried only as model memory.';summary['prompt_variant']=args.variant
 (out/'summary.json').write_text(json.dumps(summary,indent=2))
