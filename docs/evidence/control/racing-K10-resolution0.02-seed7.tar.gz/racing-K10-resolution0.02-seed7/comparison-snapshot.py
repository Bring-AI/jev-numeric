"""Controlled K/resolution comparison: fixed recovery policy, natural termination."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import sys

from decoder import decode

HERE=Path(__file__).resolve().parent
RECOVERY=HERE.parents[1]/'car-racing-20260923/recovery/recover.py'
spec=importlib.util.spec_from_file_location('racing_recovery',RECOVERY)
rec=importlib.util.module_from_spec(spec);sys.modules[spec.name]=rec;spec.loader.exec_module(rec)
r=rec.r


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--seed',type=int,required=True)
    parser.add_argument('--branching',type=int,default=20)
    parser.add_argument('--resolution',default='0.005')
    parser.add_argument('--reverse',action='store_true')
    args=parser.parse_args();r.credentials()
    policy=rec.Policy()
    def act(client,state,reverse=False):
        state=policy.prepare(state)
        action,trace=decode(client,state,branching=args.branching,resolution=args.resolution,reverse=reverse)
        t=state['telemetry']
        policy.history.append({'speed_before':t['speed'],'road_heading_right_degrees':t['road_heading_right_degrees'],
                               'road_center_right_offset':t['road_center_right_offset'],'wheels_on_road':t['wheels_touching_road'],
                               'steering_executed':action[0],'signed_pedal_executed':action[1]})
        return action,trace
    original_client=r.JevClient
    def client(**kwargs):
        kwargs['max_calls']=2700
        return original_client(**kwargs)
    r.JevClient=client;r.decode_action=act;r.STALL_STEPS=9001
    r.ROOT=HERE/f'K{args.branching}-resolution{args.resolution}'
    r.ROOT.mkdir(exist_ok=True)
    summary=r.play('NumericJev',args.seed,args.reverse,limit=9000)
    out=Path(summary['video']).parent
    for src,label in [(Path(__file__),'comparison-snapshot.py'),(HERE/'decoder.py','decoder-snapshot.py'),(RECOVERY,'recovery-snapshot.py')]:shutil.copy2(src,out/label)
    summary.update(branching=args.branching,resolution=args.resolution,variant='direct-history-v1-natural-termination',
                   no_new_tiles_guard=False,sim_time_limit_s=180,executed_action_overrides=0,
                   policy_instructions=rec.POLICY,history_controls=6,success=summary['stop_reason']=='lap_finished')
    (out/'summary.json').write_text(json.dumps(summary,indent=2))


if __name__=='__main__':main()
