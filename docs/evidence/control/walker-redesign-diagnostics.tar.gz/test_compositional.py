import unittest
from decimal import Decimal

from compositional import decode_terms, compose_actions, gait_from_answers


class ChosenValues:
    """Returns predetermined model predictions, deliberately ignoring arithmetic."""
    def __init__(self, targets):
        self.targets = targets
        self.calls = []

    def ask(self, state, questions):
        self.calls.append((state, questions))
        answers = {}
        for name, q in questions.items():
            target = Decimal(str(self.targets[name]))
            for key, text in q['criteria'].items():
                low, high = text.split(' <= number < ')
                if Decimal(low) <= target < Decimal(high):
                    answers[name] = {'choice': key}
                    break
            else:
                raise AssertionError((name, target, q))
        return {'answers': answers}


class CompositionalTests(unittest.TestCase):
    def test_execution_uses_selected_numbers_not_expression_answers(self):
        model = ChosenValues({'a': .25, 'b': -.15, 'zero': 0})
        units, trace = decode_terms(model, {'a': '100 - 100', 'b': '2 + 2', 'zero': '99'}, log_path=None)
        self.assertEqual(units, {'a': 50, 'b': -30, 'zero': 0})
        self.assertEqual(compose_actions(units, {'motor': ['a', 'b']}), [.1])
        self.assertEqual(len(model.calls), 3)
        self.assertTrue(all(len(q['criteria']) <= 20 for _, qs in model.calls for q in qs.values()))

    def test_zero_and_negative_values_have_centered_bins(self):
        units, _ = decode_terms(ChosenValues({'a': -.001, 'b': -.004, 'c': .004}), {'a': '0', 'b': '0', 'c': '0'}, log_path=None)
        self.assertEqual(units, {'a': 0, 'b': -1, 'c': 1})

    def test_only_explicit_summation_and_physical_clipping(self):
        self.assertEqual(compose_actions({'a': 400, 'b': -450, 'c': 3}, {'high': ['a', 'c'], 'low': ['b'], 'cancel': ['a', 'b', 'c']}), [.995, -1., -.235])

    def test_phase_transition_uses_model_answers_with_chained_updates(self):
        # SWING can enter LOWER then PUSH and switch in the same action.
        self.assertEqual(gait_from_answers(1, 0, {'behind': True, 'contact': True, 'knee_high': False, 'fast': True}), ('LOWER_PUSH_SWITCH', 1, 1))
        # Fast motion alone cannot switch while the swing condition is unmet.
        self.assertEqual(gait_from_answers(1, 0, {'behind': False, 'contact': True, 'knee_high': True, 'fast': True}), ('SWING', 1, 0))
        self.assertEqual(gait_from_answers(2, 1, {'contact': False, 'knee_high': True, 'fast': True}), ('LOWER', 2, 1))


if __name__ == '__main__':
    unittest.main()
