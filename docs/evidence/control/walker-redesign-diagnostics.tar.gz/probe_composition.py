"""Archived arithmetic fidelity study; never executes game actions."""
import ast
import importlib.util
import json
from pathlib import Path
from decimal import Decimal
from compositional import decode_terms, compose_actions, term_expressions, ask_logged

ROOT = Path(__file__).resolve().parent
OLD = ROOT.parent / 'prompt-recovery-20260924/bipedalwalker'
spec = importlib.util.spec_from_file_location('oldwalker', OLD / 'run_walker.py')
w = importlib.util.module_from_spec(spec); spec.loader.exec_module(w)


def offline_value(expression):
    tree = ast.parse(expression, mode='eval')
    allowed = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Mult, ast.Sub, ast.Add, ast.UAdd, ast.USub, ast.Constant)
    assert all(isinstance(n, allowed) for n in ast.walk(tree))
    return eval(compile(tree, 'offline-scoring-only', 'eval'), {'__builtins__': {}})


def direct(client, old_questions, log):
    windows = {name: (0, 400) for name in old_questions}
    for depth in range(2):
        questions, cuts = {}, {}
        for name, (lo, hi) in windows.items():
            n = min(20, hi-lo)
            c = [lo+(hi-lo)*i//n for i in range(n+1)]; cuts[name] = c
            label = lambda i: str(Decimal(-1) + Decimal('.005') * i)
            questions[name] = {'type': 'choice', 'instructions': old_questions[name]['instructions'],
                               'criteria': {str(i): f'{label(c[i])} <= torque < {label(c[i+1])}' for i in range(n)}}
        response = ask_logged(client, {'task': 'Calculate each focused motor equation; no previous motor commands'}, questions, log, 'direct_baseline')
        for name in questions:
            i = int(response['answers'][name]['choice']); windows[name] = tuple(cuts[name][i:i+2])
    return [float(Decimal(-1) + Decimal('.005')*lo) for lo, hi in windows.values()]


if __name__ == '__main__':
    out = ROOT / 'term-probes'; out.mkdir(exist_ok=True)
    source = OLD / 'bipedalwalker-seed7-v9_sequential-hold1'
    actions = [json.loads(line) for line in (source/'actions.jsonl').read_text().splitlines()]
    records = [json.loads(line) for line in (source/'api-records.jsonl').read_text().splitlines()]
    motor = [r for r in records if r.get('kind') == 'motor_interval']
    log = out/'api-records.jsonl'
    assert not log.exists(), 'Preserve previous probes; use another output directory.'
    w.b.credentials()
    results = []
    with w.b.JevClient(model=w.b.MODEL, max_calls=80) as client:
        for i in [0,1,3,10,30,60,100,150,220,300]:
            row = actions[i]
            goals = row['trace'][0]['disclosed_angle_goal_template']
            expressions, components = term_expressions(row['observation'], goals)
            first = client.calls
            # Truth is computed for scoring only AFTER real model inference.
            units, trace = decode_terms(client, expressions, log)
            composed = compose_actions(units, components)
            baseline = direct(client, motor[2*i]['request']['questions'], log)
            exact_terms = {name: offline_value(expr) for name, expr in expressions.items()}
            expected = [max(-1, min(.995, sum(exact_terms[n] for n in names))) for names in components.values()]
            result = {'source_decision': i, 'expressions': expressions, 'components': components, 'model_units': units,
                      'composed': composed, 'direct': baseline, 'expected_offline_only': expected,
                      'errors_composed': [a-b for a,b in zip(composed, expected)],
                      'errors_direct': [a-b for a,b in zip(baseline, expected)],
                      'api_calls_start': first, 'api_calls_end': client.calls, 'term_trace': trace}
            results.append(result)
            (out/'results.json').write_text(json.dumps(results, indent=2))
            print(json.dumps({k:result[k] for k in ['source_decision','composed','direct','expected_offline_only']}), flush=True)
    summary = {}
    for method in ['composed','direct']:
        errors = [e for r in results for e in r['errors_'+method]]
        summary[method] = {'N':len(errors), 'MAE':sum(abs(e) for e in errors)/len(errors),
                           'signed_bias':sum(errors)/len(errors), 'over_0.2':sum(abs(e)>.2 for e in errors),
                           'max_error':max(abs(e) for e in errors)}
    (out/'summary.json').write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary), flush=True)
