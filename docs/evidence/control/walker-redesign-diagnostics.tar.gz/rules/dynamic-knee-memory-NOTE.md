# Offline dynamic support-knee memory check

This is an offline design test, not a new NumericJev episode or a live-policy change. The source rule is `BipedalWalkerHeuristics.step_heuristic` in installed Gymnasium 1.3.0. Only its support-knee memory is restored; all current comparison-v2 gains, gait thresholds, normal terrain, seed definitions, and the 1600-frame horizon remain fixed. Inputs use Python six-decimal rounding, each feedback term is rounded to a centered 0.005 bin using Decimal arithmetic, integer terms are summed and clipped, and applied actions are float32 as in production.

## Model-compatible discrete update

Let memory K represent a knee target in units of 0.005, initially K=20 (target 0.1).

1. If the previous phase is SWING, ask the model the additional comparison `vx_scaled > 0.29`. True selects a fixed increment of 12 units; false selects 6 units. Store `K = min(20, K + selected_increment)`. This is a disclosed integer memory update, not an arithmetic question to the model.
2. On the LOWER-to-PUSH contact transition, the model locates the moving knee's raw observed angle in fixed input intervals with centers spaced by 0.005. The selected integer bin becomes K, capped at 20. No Python comparison of the observed angle chooses the bin.
3. In SWING and LOWER, the support-knee goal is `0.005*K`. In PUSH, the newly supporting/moving leg's knee goal is `0.005*K`; the other knee's target remains 1.0. All other phase goals are unchanged.

The increment happens before chained transitions, and contact capture overwrites it when the same frame moves through LOWER into PUSH. The extra velocity comparison can share the existing predicate request. Contact capture needs its own model interval selection before target-dependent motor questions. The nearest-bin capture approximates the original continuous capture; floor-bin capture was included as a comparison to the former numerical-memory decoder. Both are tested explicitly below. The original public implementation's truthiness checks for zero angle targets are not copied; targets remain present even when their numerical value is zero, matching current comparison-v2 semantics.

## Results

Every table entry uses the current gains `[0.495, 2.2, 0.1375, 0.495, 0.825, 8.25]`. No coefficients were searched.

| Memory variant | Reset seed 7 | Reset seed 19 | Seed-7 actual prefix 758 | Seed-7 actual prefix 850 |
|---|---|---|---|---|
| Fixed zero control | Complete, 1570 frames | Complete, 1572 frames | Fall, 972 frames | Fall, 979 frames |
| Original continuous capture | Timeout, x=85.81 | Fall, x=51.62 | Complete, 1594 frames | Fall, 978 frames |
| Nearest 0.005 capture | Fall, x=69.74 | Timeout, x=87.08 | Complete, 1587 frames | Fall, 978 frames |
| Floor 0.005 capture | Timeout, x=87.08 | Timeout, x=87.87 | Complete, 1594 frames | Fall, 978 frames |

Prefix tests replay the exact recorded actions, while separately updating hypothetical memory from the recorded observations and model predicates. That shadow memory was not present in the actual prefix and is disclosed as an offline counterfactual. After the prefix, all subsequent actions respond to the new simulated observations. No future recorded actions are injected after the switch.

The restored memory prevents the particular later failure when applied immediately after frame 758, but cannot rescue the already slowed state at frame 850. More importantly, no dynamic-memory variant completes both original seeds from reset. **Do not promote this rule on the present evidence.** `dynamic_knee_memory_results.jsonl` retains all 16 outcomes, memory changes, and sampled trajectories; `dynamic_knee_memory.py` reproduces them.
