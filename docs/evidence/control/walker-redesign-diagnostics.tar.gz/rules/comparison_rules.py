"""Offline hand-written BipedalWalker ablations. No model, training, or API.

Reference: prompt-recovery-20260924/bipedalwalker/diagnostic_fixed_memory.py.
All candidate lists are explicit controller-design choices, not fitted policies.
"""
import argparse
import json
import math
from pathlib import Path

import gymnasium as gym
import numpy as np

ROOT = Path(__file__).resolve().parent
COEFF = [.495, 2.2, .1375, .495, .825, 8.25]
FINISH_X = (200 - 10) * (14 / 30)


def quantize(x, quantum, method="nearest"):
    if not quantum:
        return x
    if method == "nearest":
        return np.floor(x / quantum + .5) * quantum
    return np.floor(x / quantum) * quantum


def gait(s, phase, moving):
    """Exact chained reference transitions; switching affects next action only."""
    support = 1 - moving
    ht, kt = [None, None], [None, None]
    kind = "PUSH"
    if phase == 1:
        kind = "SWING"
        ht[moving], kt[moving], kt[support] = 1.1, -.6, 0.
        if s[4 + 5 * support] < .1:
            phase = 2
    if phase == 2:
        kind = "LOWER"
        ht[moving], kt[moving], kt[support] = .1, .1, 0.
        if s[8 + 5 * moving]:
            phase = 3
    if phase == 3:
        kind = "LOWER_PUSH" if kind == "LOWER" else "PUSH"
        kt[moving], kt[support] = 0., 1.
        if s[6 + 5 * support] > .88 or s[2] > .348:
            kind += "_SWITCH"
            phase, moving = 1, support
    return ht, kt, phase, moving, kind


def action(s, ht, kt, cfg):
    hg, kg, damp, bal, rot, vert = cfg.get("coeff", COEFF)
    if cfg.get("no_damping"):
        damp = 0.
    tq = cfg.get("term_quantum", 0.)
    hq, kq = cfg.get("hip_term_quantum", tq), cfg.get("knee_term_quantum", tq)
    bq = cfg.get("balance_term_quantum", hq)
    dq = cfg.get("damping_term_quantum", tq)
    q = lambda v, quant: quantize(v, quant)
    output = []
    for leg in (0, 1):
        i = 4 + leg * 5
        # Each q() is equivalent to comparisons against fixed thresholds.
        hp = q(hg * (ht[leg] - s[i]), hq) if ht[leg] is not None else 0.
        hd = q(-damp * s[i + 1], dq) if ht[leg] is not None else 0.
        hb1, hb2 = q(bal * s[0], bq), q(rot * s[1], bq)
        kp = q(kg * (kt[leg] - s[i + 2]), kq)
        kd = q(-damp * s[i + 3], dq)
        kv = q(-vert * s[3], kq)
        output.extend([hp + hd + hb1 + hb2, kp + kd + kv])
    return np.asarray(output)


def composition_units(s, ht, kt, cfg):
    """Exact integer composition corresponding to per-term grid-center choices."""
    hg, kg, damp, bal, rot, vert = cfg.get("coeff", COEFF)
    tq = cfg.get("term_quantum", .005)
    hq, kq = cfg.get("hip_term_quantum", tq), cfg.get("knee_term_quantum", tq)
    bq, dq = cfg.get("balance_term_quantum", hq), cfg.get("damping_term_quantum", tq)
    def units(value, quantum):
        return math.floor(float(value) / quantum + .5) * round(quantum / .005)
    torso_units = units(bal * s[0], bq)
    rotation_units = units(rot * s[1], bq)
    vertical_units = units(-vert * s[3], kq)
    output = []
    for leg in (0, 1):
        i = 4 + 5 * leg
        hip = torso_units + rotation_units
        if ht[leg] is not None:
            hip += units(hg * (ht[leg] - s[i]), hq) + units(-damp * s[i + 1], dq)
        knee = units(kg * (kt[leg] - s[i + 2]), kq) + units(-damp * s[i + 3], dq) + vertical_units
        output += [hip, knee]
    return np.asarray(output, dtype=np.int64)


def run(seed, cfg, noise_seed=0, trace=False):
    env = gym.make("BipedalWalker-v3")
    s, _ = env.reset(seed=seed)
    phase, moving, total, phase_counts = 1, 0, 0., {}
    phase_age, forced_lower = 0, 0
    noise = np.random.default_rng(noise_seed)
    records = []
    for step in range(1600):
        if "observation_python_decimals" in cfg:
            s = np.asarray([round(float(v), cfg["observation_python_decimals"]) for v in s], dtype=np.float64)
        s = np.round(s, cfg["observation_decimals"]) if "observation_decimals" in cfg else s
        previous_phase, previous_moving = phase, moving
        if cfg.get("swing_timeout") and phase == 1 and phase_age >= cfg["swing_timeout"]:
            phase = 2
            forced_lower += 1
        ht, kt, phase, moving, kind = gait(s, phase, moving)
        phase_age = phase_age + 1 if (phase, moving) == (previous_phase, previous_moving) else 0
        phase_counts[kind] = phase_counts.get(kind, 0) + 1
        motor_units = composition_units(s, ht, kt, cfg) if cfg.get("integer_composition") else None
        raw = motor_units * .005 if motor_units is not None else action(s, ht, kt, cfg)
        raw = quantize(raw, cfg.get("action_quantum", 0.), cfg.get("action_round", "nearest"))
        raw = raw + cfg.get("action_bias", 0.)
        if cfg.get("noise_uniform"):
            raw = raw + noise.uniform(-cfg["noise_uniform"], cfg["noise_uniform"], 4)
        if motor_units is not None and not any(cfg.get(k) for k in ("action_quantum", "noise_uniform", "action_bias")):
            applied = np.clip(motor_units, -200, 199) * .005
        else:
            integer_indices = np.floor(raw / .005 + (.5 if cfg.get("final_grid") == "nearest" else 0.))
            applied = np.clip(integer_indices * .005, -1, .995)
        if trace:
            records.append({"step": step, "observation": s.tolist(), "kind": kind, "hip_targets": ht, "knee_targets": kt, "action": applied.tolist(), "next_phase": phase, "next_moving_leg": moving})
        s, reward, terminated, truncated, _ = env.step(applied)
        total += float(reward)
        if terminated or truncated:
            break
    x = float(env.unwrapped.hull.position.x)
    result = {"seed": seed, "steps": step + 1, "reward": total, "x": x,
              "torso_fall": bool(env.unwrapped.game_over), "terminated": bool(terminated),
              "truncated": bool(truncated), "success": bool(terminated and not env.unwrapped.game_over and x > FINISH_X),
              "phase_counts": phase_counts, "noise_seed": noise_seed}
    result["forced_lower_count"] = forced_lower
    env.close()
    return (result, records) if trace else result


def batch(candidates, label):
    path = ROOT / f"{label}.jsonl"
    with path.open("w") as handle:
        for cfg in candidates:
            results = [run(seed, cfg) for seed in (7, 19)]
            row = {"provenance": "OFFLINE HAND-WRITTEN RULE CONTROLLER; NOT NUMERICJEV", "config": cfg, "results": results}
            handle.write(json.dumps(row) + "\n")
            handle.flush()
            print(cfg, [(r["success"], round(r["reward"], 1), round(r["x"], 1), r["steps"]) for r in results], flush=True)


def first_candidates():
    yield {"name": "exact_reference"}
    for q in [.01, .025, .05, .1, .2]:
        for rounding in ["nearest", "floor"]:
            yield {"name": f"action_{q}_{rounding}", "action_quantum": q, "action_round": rounding}
    for q in [.025, .05, .1, .2]:
        for damping in [True, False]:
            yield {"name": f"terms_{q}_damping_{damping}", "term_quantum": q, "no_damping": not damping}
    yield {"name": "no_damping", "no_damping": True}
    for q in [.025, .05, .1, .2]:
        yield {"name": f"knees_terms_{q}", "knee_term_quantum": q}
        yield {"name": f"hips_terms_{q}", "hip_term_quantum": q, "balance_term_quantum": q, "damping_term_quantum": q}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--batch", default="first")
    args = parser.parse_args()
    if args.batch == "first":
        batch(first_candidates(), "first_candidates")
