"""OFFLINE only: replay frozen Jev prefixes and test disclosed gait safeguards."""
import argparse
import hashlib
import json
from pathlib import Path

import gymnasium as gym
import numpy as np

from comparison_rules import composition_units, gait

ROOT = Path(__file__).resolve().parent
LIVE = ROOT.parent / 'runs' / 'bipedalwalker-seed7-comparison-v2' / 'actions.jsonl'
FROZEN = ROOT / 'seed7_swing_stall_prefix.json'


def freeze():
    data = LIVE.read_bytes()
    rows = []
    for line in data.splitlines():
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            break
    assert not FROZEN.exists(), 'Do not overwrite diagnosis evidence.'
    FROZEN.write_text(json.dumps({'source': str(LIVE), 'source_bytes_sha256': hashlib.sha256(data).hexdigest(),
                                 'provenance': 'ACTUAL MODEL ACTION PREFIX, REPLAY ONLY', 'rows': rows}))
    return rows


def episode(seed, cfg, prefix=0, recorded=None):
    env = gym.make('BipedalWalker-v3', hardcore=False, max_episode_steps=1600)
    state, _ = env.reset(seed=seed)
    phase, moving, age, total, switches, recoveries = 1, 0, 0, 0., 0, []
    tail = []
    for step in range(1600):
        old_phase, old_moving = phase, moving
        s = np.asarray([round(float(v), 6) for v in state], dtype=np.float64)
        if step < prefix:
            row = recorded[step]
            assert abs(round(float(env.unwrapped.hull.position.x), 4)-row['observation']['privileged_torso_x']) < 1e-9
            action = np.asarray(row['action'], dtype=np.float32)
            memory = row['trace'][0]['next_model_memory']
            phase, moving = memory['phase'], memory['moving_leg']
            kind = row['trace'][0]['model_chosen_gait_case']
        else:
            mode = cfg.get('recovery')
            slow = s[2] < cfg.get('slow_vx', .1)
            long_swing = phase == 1 and age >= cfg.get('minimum_age', 70)
            recover = mode == 'lower' and long_swing and slow
            recover |= mode == 'contact' and long_swing and bool(s[8+5*moving])
            if recover:
                recoveries.append({'step': step, 'phase_age': age, 'vx': float(s[2]), 'x': float(env.unwrapped.hull.position.x)})
                phase = 2
            ht, kt, phase, moving, kind = gait(s, phase, moving)
            if mode == 'support_goal' and long_swing and slow and kind == 'SWING':
                ht[1-old_moving] = cfg.get('support_hip_goal', 0.)
                recoveries.append({'step': step, 'phase_age': age, 'vx': float(s[2]), 'x': float(env.unwrapped.hull.position.x), 'support_hip_goal': ht[1-old_moving]})
            units = composition_units(s, ht, kt, cfg)
            action = np.asarray(np.clip(units, -200, 199) * .005, dtype=np.float32)
        age = age + 1 if (phase, moving) == (old_phase, old_moving) else 0
        switches += moving != old_moving
        state, reward, terminated, truncated, _ = env.step(action)
        total += float(reward)
        if step >= 780 and (step % 20 == 0 or terminated or truncated):
            tail.append({'step': step+1, 'x': float(env.unwrapped.hull.position.x), 'vx': float(state[2]),
                         'phase': phase, 'moving': moving, 'age': age, 'kind': kind})
        if terminated or truncated:
            break
    x = float(env.unwrapped.hull.position.x)
    result = {'provenance': 'OFFLINE SIMULATION, NOT A NEW JEV EPISODE', 'seed': seed, 'prefix_frames': prefix, 'config': cfg,
              'steps': step+1, 'reward': total, 'x': x, 'torso_fall': bool(env.unwrapped.game_over),
              'terminated': bool(terminated), 'truncated': bool(truncated),
              'success': bool(terminated and not env.unwrapped.game_over and x > 88.66666666666667),
              'final_phase': phase, 'final_moving': moving, 'final_phase_age': age, 'leg_switches': switches,
              'recoveries': recoveries, 'tail': tail}
    env.close()
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=['reference', 'recovery', 'support_goal'], default='reference')
    args = parser.parse_args()
    rows = json.loads(FROZEN.read_text())['rows'] if FROZEN.exists() else freeze()
    baseline = {'integer_composition': True, 'term_quantum': .005}
    jobs = []
    if args.stage == 'reference':
        jobs = [(seed, baseline, 0) for seed in (7,19)] + [(7, baseline, prefix) for prefix in (780,800,820,840,850,880,900,930) if prefix <= len(rows)]
    elif args.stage == 'recovery':
        for age in (50,70,90):
            cfg = dict(baseline, recovery='lower', minimum_age=age, slow_vx=.1)
            jobs += [(seed,cfg,0) for seed in (7,19)] + [(7,cfg,prefix) for prefix in (850,900) if prefix <= len(rows)]
    else:
        for goal in (0., .1, -.2):
            cfg = dict(baseline, recovery='support_goal', minimum_age=50, slow_vx=.1, support_hip_goal=goal)
            jobs += [(seed,cfg,0) for seed in (7,19)] + [(7,cfg,prefix) for prefix in (850,900) if prefix <= len(rows)]
    with (ROOT/f'swing_stall_{args.stage}.jsonl').open('w') as handle:
        for seed,cfg,prefix in jobs:
            result = episode(seed,cfg,prefix,rows)
            handle.write(json.dumps(result)+'\n');handle.flush()
            brief = {k:result[k] for k in ('seed','prefix_frames','config','steps','reward','x','success','final_phase_age')}
            brief.update(recovery_count=len(result['recoveries']), first_recoveries=result['recoveries'][:3])
            print(brief,flush=True)


if __name__ == '__main__':
    main()
