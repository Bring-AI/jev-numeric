# Offline handwritten controller design — 2026-09-24

These are **offline Gymnasium/Box2D rule-controller simulations, not NumericJev results**. No API requests, neural/tree training, GPU computation, modified physics, alternative terrain seeds, increased horizon, or future-action injection were used. All environment episodes use normal `BipedalWalker-v3`, seeds 7 or 19, one action per physics frame, and 1600 frames. Success requires native termination, no `game_over`, and `hull.x > (200-10)*(14/30) = 88.666666…`.

The baseline was copied, without importing its sweep, from `prompt-recovery-20260924/bipedalwalker/diagnostic_fixed_memory.py`: fixed support knee angle zero and coefficients `[0.495, 2.2, 0.1375, 0.495, 0.825, 8.25]`. Its original rewards/steps reproduced before ablations.

## Recommended production-matched oracle

Use the original six coefficients and chained gait, but quantize each signed feedback contribution independently to the nearest 0.005 (ties toward the greater signed value), sum exact integer 0.005 units, and clip the **sum** to integer range `[-200,199]`. Share torso-angle, torso-rotation, and vertical-velocity contributions between the legs. Round observed values with Python `round(float(value), 6)` before calculations. Never floor the final floating-point sum.

This oracle matches the parent's proposed compositional decoder structurally. Its arithmetic is an offline reference, not an authorized replacement for model term choices in a live run.

| Policy | Seed | Reward | Frames | Final x | Native success |
|---|---:|---:|---:|---:|---|
| Original exact reference | 7 | 315.3544 | 1585 | 88.68375 | yes |
| Original exact reference | 19 | 315.4863 | 1554 | 88.68301 | yes |
| Integer term 0.005, observation 6 decimals | 7 | 315.6298 | 1569 | 88.70718 | yes |
| Integer term 0.005, observation 6 decimals | 19 | 316.2746 | 1518 | 88.68216 | yes |
| Mixed integer terms, observation 6 decimals | 7 | 314.6846 | 1585 | 88.72556 | yes |
| Mixed integer terms, observation 6 decimals | 19 | 315.9450 | 1520 | 88.69011 | yes |

The final direct-integer implementation was rerun on both seeds for both recommended comparison candidates. Definitive results are `production_integer_composition_verified.jsonl`; each episode also has a complete observation/action/gait trace. Their gains and quantization resolutions were handwritten, not fit to demonstrations.

## Fully specified gait and comparison rule

Initial phase is 1, moving leg 0, supporting leg 1. Evaluate the gait before choosing motor contributions; preserve the old moving/supporting roles for this action, even if switching the memory for the next action.

| Condition, evaluated in order | Current action case | Moving hip target | Moving knee target | Support knee target |
|---|---|---:|---:|---:|
| Previous phase 1 and support hip >= 0.1 | SWING | 1.1 | -0.6 | 0 |
| Previous phase 1 and support hip < 0.1, or previous phase 2; moving foot has no contact | LOWER | 0.1 | 0.1 | 0 |
| Same LOWER entry condition, but moving foot has contact | LOWER_PUSH | 0.1 | 0 | 1 |
| Previous phase 3 | PUSH | none | 0 | 1 |

For either PUSH case only, switch the next moving leg and set next phase to 1 if support knee > 0.88 or horizontal velocity > 0.348; otherwise next phase is 3. SWING leaves phase 1, LOWER leaves phase 2. Both hip targets are absent in pure PUSH; the support hip target is always absent. Absent hip targets remove both hip P and hip D terms. This preserves the reference's sequential transition behavior, including the remaining hip target in LOWER_PUSH.

Each motor is the sum of the following signed contributions:

| Term | Expression used to define the static comparison table | Default quantum | Mixed quantum |
|---|---|---:|---:|
| Hip P, if target present | `0.495 * (target - hip_angle)` | 0.005 | 0.01 |
| Hip D, if target present | `-0.1375 * hip_speed` | 0.005 | 0.025 |
| Shared torso angle | `0.495 * torso_angle` | 0.005 | 0.01 |
| Shared torso rotation | `0.825 * torso_angular_velocity_scaled` | 0.005 | 0.01 |
| Knee P | `2.2 * (target - knee_angle_plus1)` | 0.005 | 0.1 |
| Knee D | `-0.1375 * knee_speed` | 0.005 | 0.025 |
| Shared torso vertical velocity | `-8.25 * vy_scaled` | 0.005 | 0.1 |

The model need not multiply these expressions. A table can encode each coefficient and target in fixed comparison thresholds. For quantum q and signed integer bin n:

* For an increasing term `c*x`, select n iff `(n-0.5)*q/c <= x < (n+0.5)*q/c`.
* For a decreasing term `c*(target-x)`, select n iff `target-(n+0.5)*q/c < x <= target-(n-0.5)*q/c`.
* A damping or vertical term uses the second rule with target zero.

Here c is the positive coefficient; thresholds are policy constants computed before observing the state. Each selected bin contributes `n*(q/0.005)` integer action units. Hip motors sum up to four integers; knees sum three. Clip only the sum. Shared term choices must be reused consistently. Mixed resolution removes especially fine knee P/vertical bins while preserving both offline completions, though its seed-7 time margin is smaller.

## Sensitivity and rejected alternatives

The original exact reference is highly sensitive to signed bias. All noise below is applied independently to each motor at every frame before the original final 0.005 floor grid. Repeats use noise seeds 0, 1, 2, 3 across both terrain seeds, a small diagnostic sample rather than a reliability estimate.

| Perturbation | Completions |
|---|---:|
| Uniform noise +/-0.005 | 7/8 |
| Uniform noise +/-0.01 | 8/8 |
| Uniform noise +/-0.02 | 4/8 |
| Uniform noise +/-0.04 | 5/8 |
| Constant extra bias -0.005 | 0/2 |
| Constant extra bias -0.01 | 0/2 |
| Constant extra bias -0.02 | 0/2 |
| Bias -0.01 plus noise +/-0.02 | 0/8 |

Negative bias often leaves SWING stationary at x approximately 6.6: the support hip rests at its joint limit and the support-hip threshold never fires. Therefore, decoding every signed term to its lower bin edge is unsuitable. Bin centers and integer summation avoid systematic accumulated negative bias. A heuristic SWING timeout at 70 or 90 frames did not improve the noisy outcomes and made biased episodes fall; it is not recommended.

Nearest output quantization at 0.05 completed both seeds, while floor output quantization at 0.01 through 0.2 generally stalled or fell. Removing damping failed. Per-term 0.025 quantization appeared successful with the reference's float32 and final-floor realization, but its exact integer-sum form stalled on both seeds: **do not promote that candidate**. The validated mixed and 0.005 candidates above use explicit integer composition.

A bounded gain ablation increased damping from 0.1375 to 0.1625 and completed in 1491/1547 frames, but only 3/8 noisy +/-0.02 repeats succeeded. Hip gain 0.525 plus knee gain 2.1 completed clean episodes in 1592/1571 frames and 6/8 noisy repeats; the time margin and sample size do not justify replacing the baseline. Rounding observations to 2–5 decimal places was also unreliable; Python six-decimal rounding is explicitly verified for the recommended compositional policy.

## Files and reproduction

`comparison_rules.py` contains the copied gait, comparison-equivalent quantizers, integer compositional oracle, noise evaluator, and first candidate list. Every later tested configuration and every episode outcome is retained in these JSONL files:

* `first_candidates.jsonl`: output/term quantization and damping ablations.
* `second_mixed_and_gains.jsonl`: mixed resolution and single-gain choices.
* `baseline_noise_bias.jsonl`: baseline signed-bias/noise sensitivity.
* `third_robustness.jsonl`: selected gains and quantized policies under perturbations.
* `fourth_grid_and_observation.jsonl`: precise motor-grid interpretation and observation rounding.
* `fifth_timeout.jsonl`: rejected SWING timeout safeguard.
* `production_integer_composition_verified.jsonl`: definitive final configurations and direct integer clipping results.

Replay any result file with:

```sh
/tmp/numericjev-racing-env/bin/python /data/yww/notebook/numericjev-game-experiments/walker-redesign-20260924/rules/replay_results.py /data/yww/notebook/numericjev-game-experiments/walker-redesign-20260924/rules/production_integer_composition_verified.jsonl
```

This produces a separate replayed file and does not overwrite the archived results.
