"""Bounded OFFLINE test of public heuristic knee memory in comparison control.

No API, learned policy, or live-run changes. Dynamic targets are reconstructed
from raw observations only for the offline reference/continuation experiment.
"""
from decimal import Decimal, ROUND_FLOOR
import json
from pathlib import Path

import gymnasium as gym
import numpy as np

from audit_composed import D, STEP, exact_terms, state_transition, telemetry

ROOT = Path(__file__).resolve().parent
PREFIX = ROOT / 'seed7_swing_stall_prefix.json'


def nearest_units(value):
    return int((value / STEP + D('.5')).to_integral_value(rounding=ROUND_FLOOR))


def update_and_goals(observation, phase, moving, knee_memory, mode, predicates=None):
    other = 1-moving
    m, u = observation[f'leg{moving}'], observation[f'leg{other}']
    if predicates is None:
        predicates = {'behind': u['hip_angle'] < .1, 'contact': m['ground_contact'] == 1,
                      'knee_high': u['knee_angle_plus1'] > .88, 'fast': observation['vx_scaled'] > .348}
    original_memory = knee_memory
    event = 'hold'
    if mode == 'fixed0':
        knee_memory = D(0)
    elif phase == 1:
        knee_memory = min(D('.1'), knee_memory + (D('.06') if observation['vx_scaled'] > .29 else D('.03')))
        event = 'increment12_units' if observation['vx_scaled'] > .29 else 'increment6_units'
    kind, next_phase, next_moving = state_transition(phase, moving, predicates)
    if mode != 'fixed0' and kind.startswith('LOWER_PUSH'):
        measured = D(m['knee_angle_plus1'])
        if mode == 'nearest005':
            measured = STEP * nearest_units(measured)
        elif mode == 'floor005':
            measured = STEP * int((measured / STEP).to_integral_value(rounding=ROUND_FLOOR))
        knee_memory = min(D('.1'), measured)
        event = 'contact_capture'
    goals = {f'leg{moving}_hip': 1.1 if kind == 'SWING' else .1 if kind.startswith('LOWER') else None,
             f'leg{other}_hip': None,
             f'leg{moving}_knee': -.6 if kind == 'SWING' else .1 if kind == 'LOWER' else float(knee_memory),
             f'leg{other}_knee': float(knee_memory) if kind in ('SWING','LOWER') else 1.}
    return kind, next_phase, next_moving, knee_memory, goals, {'event':event,'previous_k':float(original_memory),'next_k':float(knee_memory)}


def run(seed, mode, prefix, rows):
    env = gym.make('BipedalWalker-v3', hardcore=False, max_episode_steps=1600)
    state,_ = env.reset(seed=seed)
    phase,moving,knee_memory,total = 1,0,D('.1'),0.
    changes=[];samples=[]
    for step in range(1600):
        observation=telemetry(state,env)
        predicates=rows[step]['trace'][0]['model_predicates'] if step<prefix else None
        kind,next_phase,next_moving,knee_memory,goals,change=update_and_goals(observation,phase,moving,knee_memory,mode,predicates)
        if change['event']=='contact_capture' or (step>=prefix and change['previous_k']!=change['next_k']):
            changes.append(dict(step=step,**change))
        if step<prefix:
            assert observation==rows[step]['observation']
            memory=rows[step]['trace'][0]['next_model_memory']
            assert (next_phase,next_moving)==(memory['phase'],memory['moving_leg'])
            action=np.asarray(rows[step]['action'],dtype=np.float32)
        else:
            values,parts=exact_terms(observation,goals)
            units={name:nearest_units(value) for name,value in values.items()}
            action=np.asarray([float(STEP*max(-200,min(199,sum(units[name] for name in parts[motor])))) for motor in parts],dtype=np.float32)
        phase,moving=next_phase,next_moving
        state,reward,terminated,truncated,_=env.step(action)
        total+=float(reward)
        if step%40==0 or terminated or truncated:
            samples.append({'step':step+1,'x':float(env.unwrapped.hull.position.x),'phase':phase,'moving':moving,'knee_memory':float(knee_memory),'vx':float(state[2])})
        if terminated or truncated:break
    x=float(env.unwrapped.hull.position.x)
    result={'provenance':'OFFLINE RULE CONTROLLER; NOT A NEW JEV EPISODE','mode':mode,'seed':seed,'prefix_frames':prefix,
            'prefix_memory_initialization':'Shadow memory updated from prefix observations and recorded model predicates; prefix actions remain unchanged.' if prefix else 'Initial k=0.1.',
            'steps':step+1,'reward':total,'x':x,'success':bool(terminated and not env.unwrapped.game_over and x>88.66666666666667),
            'terminated':bool(terminated),'truncated':bool(truncated),'torso_fall':bool(env.unwrapped.game_over),'final_knee_memory':float(knee_memory),
            'memory_changes':changes,'trajectory_samples':samples}
    env.close();return result


if __name__=='__main__':
    rows=json.loads(PREFIX.read_text())['rows']
    with (ROOT/'dynamic_knee_memory_results.jsonl').open('w') as f:
        for mode in ['fixed0','continuous_capture','nearest005','floor005']:
            for seed,prefix in [(7,0),(19,0),(7,758),(7,850)]:
                result=run(seed,mode,prefix,rows)
                f.write(json.dumps(result)+'\n');f.flush()
                print({k:result[k] for k in ['mode','seed','prefix_frames','steps','reward','x','success']},flush=True)
