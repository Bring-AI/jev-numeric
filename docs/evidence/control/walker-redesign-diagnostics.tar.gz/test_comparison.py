import unittest
from decimal import Decimal
from comparison import descriptors, intervals, decode_comparisons
from compositional import compose_actions


class ComparisonTests(unittest.TestCase):
    def test_inverse_thresholds_ignore_observed_value(self):
        a = {'value': '.2', 'slope': '-2.2', 'origin': '.1'}
        b = dict(a, value='-.8')
        self.assertEqual(intervals(a, 0, 6401), intervals(b, 0, 6401))

    def test_selected_model_bin_drives_output_even_when_wrong(self):
        class Wrong:
            def ask(self, state, questions):
                return {'answers': {n: {'choice': 'c00'} for n in questions}}
        units, trace = decode_comparisons(Wrong(), {'term': {'value': '99', 'slope': '1', 'origin': '0'}})
        self.assertEqual(units, {'term': -3200})
        self.assertEqual(compose_actions(units, {'motor': ['term']}), [-1])
        self.assertEqual(len(trace), 3)

    def test_increasing_and_decreasing_boundaries(self):
        for slope in ['.495', '-2.2', '-.1375', '-8.25']:
            d = {'value': '999', 'slope': slope, 'origin': '.1'}
            parts = intervals(d, 3199, 3202)
            for part in parts:
                y = Decimal('.005') * (part['start'] - 3200)
                x = y / Decimal(slope) + Decimal('.1')
                lo, hi = map(Decimal, (part['lower'], part['upper']))
                self.assertTrue(lo < x < hi)


if __name__ == '__main__':
    unittest.main()
