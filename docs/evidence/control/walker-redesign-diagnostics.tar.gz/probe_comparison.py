import json
from pathlib import Path
from compositional import compose_actions
from comparison import descriptors, decode_comparisons
from probe_composition import w, ROOT, OLD

out=ROOT/'comparison-probes'; out.mkdir(exist_ok=True)
log=out/'api-records.jsonl'; assert not log.exists()
old=json.loads((ROOT/'term-probes/results.json').read_text())
actions=[json.loads(x) for x in (OLD/'bipedalwalker-seed7-v9_sequential-hold1/actions.jsonl').read_text().splitlines()]
w.b.credentials(); results=[]
with w.b.JevClient(model=w.b.MODEL,max_calls=40) as client:
 for row in old:
  a=actions[row['source_decision']]
  terms,components=descriptors(a['observation'],a['trace'][0]['disclosed_angle_goal_template'])
  units,trace=decode_comparisons(client,terms,log)
  pred=compose_actions(units,components)
  result={'source_decision':row['source_decision'],'descriptors':terms,'components':components,'model_units':units,'prediction':pred,'expected_offline_only':row['expected_offline_only'],'errors':[x-y for x,y in zip(pred,row['expected_offline_only'])],'trace':trace}
  results.append(result); (out/'results.json').write_text(json.dumps(results,indent=2));print(json.dumps({k:result[k] for k in ['source_decision','prediction','errors']}),flush=True)
errs=[e for r in results for e in r['errors']]
summary={'N':len(errs),'MAE':sum(map(abs,errs))/len(errs),'bias':sum(errs)/len(errs),'over_0.2':sum(abs(e)>.2 for e in errs),'max_error':max(map(abs,errs))}
(out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary),flush=True)
