"""Direct Jev numeric controls with explicit history and recovery instructions."""
import argparse
import copy
import importlib.util
import json
import math
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = HERE.parent
spec = importlib.util.spec_from_file_location('original_racing', BASE / 'run.py')
r = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = r
spec.loader.exec_module(r)

POLICY = '''Your task is to complete the track, not merely avoid motion. Commands are absolute controls, not changes to the previous command. Recompute them from current telemetry. You must move forward to turn; steering cannot rotate a stationary car. Braking at near-zero speed or coasting indefinitely prevents completion.
Use a conservative speed: roughly 12-16 on straight road and 6-10 in tight turns or while recovering. This simulator has strong brakes: brake 0.10 can remove about 6 speed units in just 0.20 seconds. Brake gently, typically 0.02-0.04 when necessary, and release brakes before reaching zero. When speed is under 5, including at standstill or partly on grass, choose positive throttle, usually 0.04-0.10, and steer back toward the road. A bend is not a reason to stay stopped. Zero pedal at zero speed means permanent standstill and must not be selected.
For steering, aim toward the road-center point about 4 tiles ahead. Its coordinates and bearing are relative to the car: right positive means turn right, negative means left. At speed, steering 0.1 already turns substantially. Use small steering for small errors; use stronger steering, around 0.3-0.6, at low speed if the target is far to the side or behind. If targets are behind, turn toward their signed side while applying gentle throttle to recover; stopping will not align the car. Reduce steering or countersteer when the heading and yaw show that you are overshooting. Previous actions are historical observations, not instructions to repeat them.'''


class Policy:
    def __init__(self):
        self.history = []
        self.stationary_s = 0.

    def prepare(self, state):
        state = copy.deepcopy(state)
        telemetry = state['telemetry']
        self.stationary_s = self.stationary_s + .2 if telemetry['speed'] < .2 else 0.
        telemetry['stationary_duration_s'] = round(self.stationary_s, 2)
        telemetry['recent_controls_oldest_first'] = self.history[-6:]
        state['rules'] = POLICY
        return state

    def decode(self, client, state, reverse=False):
        state = self.prepare(state)
        raw = r.decode_action

        class W:
            def __init__(self): self.depth = 0
            def ask(inner, st, questions):
                questions = copy.deepcopy(questions)
                for name,q in questions.items():
                    q['instructions'] = POLICY + '\n\n' + q['instructions']
                    if inner.depth == 1:
                        q['instructions'] += ' These final options show exact controls that will be executed.'
                        for key,desc in q['criteria'].items():
                            value = desc.split(' <= ')[0]
                            v = float(value)
                            if name == 'signed_acceleration':
                                effect = f'BRAKE {abs(v):.2f}' if v < 0 else f'THROTTLE {v:.2f}' if v > 0 else 'COAST; no throttle or brake; cannot start moving'
                            else: effect = 'LEFT' if v < 0 else 'RIGHT' if v > 0 else 'STRAIGHT'
                            q['criteria'][key] = f'Execute {name}={value}: {effect}.'
                inner.depth += 1
                return client.ask(st, questions)

        action,trace = ORIGINAL_DECODE(W(),state,reverse)
        t=state['telemetry']
        self.history.append({'speed_before':t['speed'],'road_heading_right_degrees':t['road_heading_right_degrees'],
                             'road_center_right_offset':t['road_center_right_offset'],'wheels_on_road':t['wheels_touching_road'],
                             'steering_executed':action[0],'signed_pedal_executed':action[1]})
        return action,trace


ORIGINAL_DECODE = r.decode_action


def probes():
    records = json.loads((BASE/'diagnostics/explicit-leaf-actions/NumericJev-seed19/api-records.json').read_text())
    state=records[2*210]['request']['state']
    original=records[2*210+1]['response']['answers']['signed_acceleration']['choice']
    assert original=='0'
    (HERE/'fixed-state-original.json').write_text(json.dumps(records[2*210:2*210+2],indent=2))
    results=[]
    for reverse in [False,True]:
        p=Policy()
        with r.JevClient(max_calls=2,model=r.MODEL) as client:
            action,trace=p.decode(client,state,reverse)
            result={'reverse':reverse,'action':action,'trace':trace}
            (HERE/f'fixed-state-recovery-{reverse}.json').write_text(json.dumps({'result':result,'records':client.records},indent=2))
            print(json.dumps(result),flush=True);results.append(result)
    return results


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--seed',type=int,default=19)
    parser.add_argument('--reverse',action='store_true')
    parser.add_argument('--probe',action='store_true')
    args=parser.parse_args();r.credentials()
    if args.probe: probes(); return
    p=Policy();r.decode_action=p.decode
    r.ROOT=HERE/'direct-history-v1';r.ROOT.mkdir(exist_ok=True)
    summary=r.play('NumericJev',args.seed,args.reverse,limit=9000)
    out=Path(summary['video']).parent
    shutil.copy2(__file__,out/'recovery-snapshot.py')
    summary.update(variant='direct-history-v1',sim_time_limit_s=180,executed_action_overrides=0,
                   policy_instructions=POLICY,history_controls=6)
    (out/'summary.json').write_text(json.dumps(summary,indent=2))


if __name__=='__main__':main()
