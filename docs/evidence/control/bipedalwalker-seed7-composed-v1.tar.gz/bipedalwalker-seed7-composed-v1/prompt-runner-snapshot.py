"""Live compositional NumericJev Walker; all numeric contributions inferred by Jev."""
import argparse
import importlib.util
import json
from pathlib import Path
import shutil

from compositional import choose_gait, angle_goals, term_expressions, decode_terms, compose_actions, COEFFICIENTS

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / 'multigame-20260924/games/run_games.py'
spec = importlib.util.spec_from_file_location('base_games', BASE)
b = importlib.util.module_from_spec(spec); spec.loader.exec_module(b)


class ComposedWalker:
    def __init__(self, coefficients=COEFFICIENTS):
        self.phase = 1
        self.moving = 0
        self.coefficients = coefficients

    def decode(self, client, config, state, reverse, path):
        assert not reverse, 'This protocol records forward option order.'
        observation = state['observation']
        previous = {'phase': self.phase, 'moving_leg': self.moving}
        (kind, phase, moving), predicates = choose_gait(client, self.phase, self.moving, observation, path)
        goals = angle_goals(kind, self.moving)
        expressions, components = term_expressions(observation, goals, self.coefficients)
        units, trace = decode_terms(client, expressions, path)
        action = compose_actions(units, components)
        assert list(components) == config['names']
        self.phase, self.moving = phase, moving
        return action, [{'protocol': 'composed-v1', 'previous_model_memory': previous,
                         'model_predicates': predicates, 'model_chosen_gait_case': kind,
                         'next_model_memory': {'phase': phase, 'moving_leg': moving},
                         'disclosed_angle_goal_template': goals,
                         'expressions': expressions, 'components': components,
                         'model_term_units': units, 'unit_step': '.005',
                         'composition': 'Sum model-selected signed integer units per motor; clip to[-200,199]; multiply by0.005.'},
                        *trace]


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--seed', type=int, default=7)
    args = parser.parse_args()
    out_root = ROOT / 'runs'; out_root.mkdir(exist_ok=True)
    out = out_root / f'bipedalwalker-seed{args.seed}-composed-v1'
    assert not out.exists(), 'Never overwrite an earlier live episode.'
    b.ROOT = out_root
    b.credentials()
    c = b.CONFIG['bipedalwalker']
    c.update(hold=1, guidance='Jev independently classifies four gait comparisons, then numerically decodes signed feedback contributions. '
             'Explicit deterministic addition/clipping combines ONLY model term readouts into motor commands; no exact motor target or fallback.',
             rules='Compositional numerical control. All observations are current raw proprioception rounded to6decimals. '
             'No game image, lidar, terrain lookahead or torso position is sent to Jev. '
             'The phase uses model-evaluated predicates and disclosed chained transition rules. '
             'Support-knee target-angle0 is fixed. Each arithmetic contribution is a separate NumericJev inference on a centered0.005grid over[-16,16]. '
             'The adapter sums those model values and clips to[-1,0.995]. Control updates every physics frame; no overrides.')
    b.decode_action = ComposedWalker().decode
    old_client = b.JevClient
    b.JevClient = lambda **kw: old_client(**dict(kw, max_calls=6500))
    # Snapshot the exact runner/decoder BEFORE launching an episode.
    snapshot = ROOT/'snapshots'/'composed-v1'
    snapshot.mkdir(parents=True, exist_ok=True)
    for source, name in [(Path(__file__), 'prompt-runner-snapshot.py'), (ROOT/'compositional.py', 'compositional-snapshot.py')]:
        target = snapshot/name
        if target.exists():
            assert target.read_bytes() == source.read_bytes(), 'Use a new version after changing source.'
        else:
            shutil.copy2(source, target)
    summary = b.play('bipedalwalker', args.seed, attempt='composed-v1', wall_limit=3600)
    for source in snapshot.iterdir():
        shutil.copy2(source, out/source.name)
    summary.update(
        protocol='composed-v1', coefficients=COEFFICIENTS,
        state_access='Jev sees raw joint/body values in arithmetic expressions and four simple numerical comparisons. No lidar/torso position/image is given. Those fields exist only in diagnostic logs.',
        intermediate_gait_protocol='Four independent binary comparisons in1request; deterministic chained logic combines model booleans. ThreeK20requests decode model signed terms; deterministic integer addition/clipping composes four motors.4APIcalls perphysicsframe.',
        grid={'term_centers': [-16,16], 'term_grid_spacing': '.005', 'term_count': 6401,
              'bin_boundaries': 'half a grid step below/above each center', 'term_readout': 'selected interval center',
              'physical_motor_range': [-1,.995], 'physical_motor_grid_spacing': '.005',
              'composition': 'sum signed integer term units, clip to[-200,199], scale by0.005'},
        executed_action_overrides=0,
        difference_from_direct_decoder='The final motor is an explicitly composed sum of Jev numerical term outputs, not a single whole-motor interval choice.'
    )
    (out/'summary.json').write_text(json.dumps(summary, indent=2))
