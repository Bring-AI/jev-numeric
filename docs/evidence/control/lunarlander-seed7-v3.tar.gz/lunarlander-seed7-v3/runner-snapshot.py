"""Live Jev experiments: explicit control guidance, unmodified Gymnasium dynamics."""
import os
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")

import argparse
from collections import deque
from decimal import Decimal
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import time

import gymnasium as gym
import imageio.v2 as imageio
import imageio_ffmpeg
import numpy as np
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, '/data/yww/notebook/jev-numeric/src')
from jev_numeric import JevClient

ROOT = Path(__file__).resolve().parent
MODEL = 'typesafe/jev-1.13-20260917'
K = 20
RESOLUTION = Decimal('0.005')
LOW = Decimal('-1')
POINTS = 400
COMMON = '''You control a real continuous-action game. Select each action component from the supplied numeric intervals. Your choices alone determine the actions; no other controller corrects them. All components are selected together and then held for the stated number of physics steps. The simulation pauses during inference. Read the structured observations and recent history. Labels identify intervals, not numerical actions. Every final interval has width 0.005 and its lower endpoint is executed. The controllable grid is [-1, 1), so maximum positive control is 0.995. Control guidance is supplied explicitly below; no target actions have been precomputed for you.'''

CONFIG = {
    'lunarlander': {
        'environment': 'LunarLander-v3', 'title': 'Lunar Lander',
        'kwargs': {'continuous': True}, 'fps': 50, 'hold': 5, 'limit': 1000,
        'names': ['main_engine', 'lateral_engine'],
        'description': 'Two engine commands; land softly on the central pad.',
        'rules': '''Land upright and gently on the center pad, x=0 and y near zero. Observations are Gymnasium's normalized state, not SI values. x is horizontal position relative to pad; y is height; vx positive right; vy positive upward; angle positive means counterclockwise tilt (main thrust pushes LEFT); angular_velocity positive increases angle. main_engine <=0 is OFF, main_engine >0 fires with power=(main_engine+1)/2. lateral_engine has a deadzone [-0.5,+0.5]; it fires only outside that range. Positive lateral_engine decreases angle (clockwise); negative increases angle. Never use a small nonzero lateral action expecting small thrust: abs(action)<=0.5 is off.
Explicit heuristic guidance, adapted from Gymnasium's public heuristic: form a desired tilt clip(0.5*x + vx, -0.4, 0.4). Stabilize angle and angular velocity toward it; an approximate lateral command is clip(-20 * (0.5*(desired_tilt-angle) - angular_velocity), -1, 0.995). Use a desired hover height 0.55*abs(x), and approximate main command clip(20*(0.5*(desired_hover_height-y) - 0.5*vy)-1, -1, 0.995). If either leg touches ground, keep lateral off and use main command approximately clip(-10*vy-1,-1,0.995) to avoid bouncing. These are explicit controller-in-prompt guides; infer the numeric commands yourself from current observations. React every 5 frames (0.10 seconds). A safely sleeping lander terminates with +100; crashes or leaving bounds terminate with -100. Reward >=200 is the environment's solution score.''',
        'guidance': 'Explicit arithmetic control guidance adapted from the Gymnasium lunar-lander heuristic; targets are computed by Jev through choices, not by Python.',
    },
    'mountaincar': {
        'environment': 'MountainCarContinuous-v0', 'title': 'Continuous Mountain Car',
        'kwargs': {}, 'fps': 30, 'hold': 4, 'limit': 999,
        'names': ['motor_force'],
        'description': 'One continuous motor force; build momentum and reach the right hilltop.',
        'rules': '''Reach position >=0.45 with velocity >=0. The starting position is near -0.5 and speed is zero. A positive motor_force accelerates RIGHT; negative accelerates LEFT. The engine is too weak to climb directly from rest: build energy by swinging back and forth. Physics per step: velocity += 0.0015*force - 0.0025*cos(3*position), then position += velocity. At the left wall -1.2, leftward speed resets to zero. Velocity is clipped to [-0.07,0.07]. Explicit energy-pumping guidance: generally accelerate strongly in the current direction of motion; when moving LEFT choose a strongly negative force, and when moving RIGHT choose a strongly positive force. At nearly zero speed in the valley, first push left to start a swing; near a turning point reverse the force as the velocity reverses. Do not keep pushing toward the goal while the car is rolling left: that removes energy. Hold each chosen force for 4 simulation steps. Reward is 100 on reaching the goal minus 0.1*force^2 every step; reaching the goal is more important than small action cost.''',
        'guidance': 'Explicit qualitative energy-pumping heuristic and exact environment transition equation, with no precomputed action supplied.',
    },
    'bipedalwalker': {
        'environment': 'BipedalWalker-v3', 'title': 'Bipedal Walker',
        'kwargs': {'hardcore': False}, 'fps': 50, 'hold': 5, 'limit': 1600,
        'names': ['leg0_hip', 'leg0_knee', 'leg1_hip', 'leg1_knee'],
        'description': 'Four continuous joint commands; attempt forward walking on normal terrain.',
        'rules': '''Walk to the RIGHT without letting the torso touch the ground. Four actions control leg0 hip/knee then leg1 hip/knee. The implementation uses sign(action) for target motor direction and abs(action) for maximum torque fraction; positive increases the corresponding joint angle, negative decreases it. Hip normalized angle limits are -0.8 to +1.1: a positive hip swings the foot forward/right, negative swings it back. The observed knee angle is physical joint angle +1, with limits -0.6 (bent/folded) to +0.9 (extended). Positive knee action extends the knee; negative bends it. Joint velocities are normalized by motor speed. The torso angle is positive counterclockwise and its scaled angular velocity has the same sign. Contacts say whether each lower leg touches ground.
Explicit gait guidance: alternate supporting and swinging legs. Begin with leg1 supporting and leg0 swinging forward: keep the support knee around +0.1, swing leg0 hip toward +1.0 and bend its knee toward -0.5. When the supporting hip moves behind the torso (hip angle below about +0.1), lower the moving foot by bringing its hip toward +0.1 and knee toward +0.1. Once that foot contacts ground, transfer support to it and extend the old support knee to push off, then swap legs. Use current state and recent history to infer this phase; no gait phase or target actions are supplied by code. Damp joint motion instead of saturating every joint. Balance the torso around angle zero: a positive torso angle or angular velocity calls for a positive correction to BOTH hip commands; negative calls for negative correction. Downward torso velocity calls for extending the knees. A useful joint-tracking guide is proportional angle-error minus damping of joint speed, with moderate hip gain and stronger knee gain. React every 5 frames (0.10 seconds). Keep the torso high and avoid excessive torque. Falling receives -100 and ends the episode. Normal terrain, no obstacles.''',
        'guidance': 'Qualitative alternating support/swing gait, joint tracking, and balance guidance; Jev infers gait and all four commands from observations/history.',
    },
}


def credentials():
    spec = importlib.util.spec_from_file_location('existing_racing_runner', '/data/yww/notebook/numericjev-game-experiments/car-racing-20260923/run.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.credentials()


def observation_dict(game, observation, env):
    o = [round(float(x), 6) for x in observation]
    if game == 'lunarlander':
        return dict(zip(['x', 'y', 'vx', 'vy', 'angle', 'angular_velocity', 'leg0_contact', 'leg1_contact'], o))
    if game == 'mountaincar':
        return {'position': o[0], 'velocity': o[1]}
    return {
        'torso_angle': o[0], 'torso_angular_velocity_scaled': o[1],
        'vx_scaled': o[2], 'vy_scaled': o[3],
        'leg0': dict(zip(['hip_angle', 'hip_speed', 'knee_angle_plus1', 'knee_speed', 'ground_contact'], o[4:9])),
        'leg1': dict(zip(['hip_angle', 'hip_speed', 'knee_angle_plus1', 'knee_speed', 'ground_contact'], o[9:14])),
        'lidar_fractions_down_to_forward': o[14:],
        'privileged_torso_x': round(float(env.hull.position.x), 4),
        'privileged_torso_y': round(float(env.hull.position.y), 4),
    }


def grid_value(index):
    return str(LOW + RESOLUTION * index)


def partitions(left, right, branching=K):
    count = min(branching, right-left)
    return [left + (right-left)*i//count for i in range(count+1)]


def decode_action(client, config, state, reverse, log_path):
    windows = {name: (0, POINTS) for name in config['names']}
    trace = []
    depth = 0
    while any(right-left > 1 for left, right in windows.values()):
        questions, cuts_by_name = {}, {}
        for name, (left, right) in windows.items():
            if right-left == 1:
                continue
            cuts = partitions(left, right)
            cuts_by_name[name] = cuts
            criteria = {str(i): f'{grid_value(cuts[i])} <= {name} < {grid_value(cuts[i+1])}' for i in range(len(cuts)-1)}
            if config.get('effect_labels'):
                for i in range(len(cuts)-1):
                    lo, hi = float(grid_value(cuts[i])), float(grid_value(cuts[i+1]))
                    if name == 'main_engine':
                        effect = 'MAIN ENGINE OFF: no upward thrust' if hi <= 0.005 else 'MAIN ENGINE ON: upward thrust slows descent'
                    else:
                        effect = 'side thrust OFF; no angle correction'
                        if hi <= -0.5:
                            effect = 'turn COUNTERCLOCKWISE; increase angle'
                        elif lo >= 0.5:
                            effect = 'turn CLOCKWISE; decrease angle'
                    criteria[str(i)] += '; '+effect
            if reverse:
                criteria = dict(reversed(list(criteria.items())))
            questions[name] = {
                'type': 'choice',
                'instructions': f'Choose the interval containing your intended {name} command under the supplied game rules, control guidance and current state. Coordinate this with the other action components. Bounds are lower-inclusive and upper-exclusive; final lower endpoint is executed for {config["hold"]} frames.',
                'criteria': criteria,
            }
        payload = {'model': MODEL, 'state': state, 'questions': questions}
        started = time.monotonic()
        try:
            response = client.ask(state, questions)
        except Exception as exc:
            with log_path.open('a') as f:
                f.write(json.dumps({'request': payload, 'error': f'{type(exc).__name__}: {exc}', 'latency_s': time.monotonic()-started})+'\n')
            raise
        with log_path.open('a') as f:
            f.write(json.dumps({'request': payload, 'response': response, 'latency_s': time.monotonic()-started})+'\n')
        for name, answer in response['answers'].items():
            choice = int(answer['choice'])
            cuts = cuts_by_name[name]
            windows[name] = (cuts[choice], cuts[choice+1])
        trace.append({'depth': depth, 'windows': dict(windows), 'choices': {name: answer['choice'] for name, answer in response['answers'].items()}})
        depth += 1
    action = [float(LOW + RESOLUTION*windows[name][0]) for name in config['names']]
    assert depth == 2 and all(-1 <= x < 1 for x in action)
    return action, trace


def annotate(frame, config, seed, step, reward, action, status='live Jev choices'):
    picture = Image.fromarray(frame)
    canvas = Image.new('RGB', (picture.width, picture.height+74), (17, 24, 39))
    canvas.paste(picture, (0, 74))
    draw = ImageDraw.Draw(canvas)
    font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 13)
    draw.text((9, 5), f'NumericJev | {config["title"]} | seed {seed} | {step/config["fps"]:.2f}s | reward {reward:.1f}', font=font, fill='white')
    draw.text((9, 25), 'actions '+', '.join(f'{v:+.3f}' for v in action)+f' | {status}', font=font, fill=(125, 211, 252))
    draw.text((9, 47), 'Guided state control | K=20, step 0.005 | API waits omitted', font=font, fill=(190, 196, 210))
    return np.array(canvas)


def make_preview(out, duration):
    ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
    vf = 'fps=8,scale=320:-1:flags=lanczos,split[s0][s1];[s0]palettegen=max_colors=128[p];[s1][p]paletteuse=dither=bayer'
    proc = subprocess.run([ffmpeg, '-y', '-v', 'error', '-ss', str(max(0, duration-12)), '-i', str(out/'replay.mp4'), '-t', '12', '-filter_complex', vf, '-loop', '0', str(out/'preview.gif')], capture_output=True, text=True)
    if proc.returncode:
        raise RuntimeError('GIF conversion failed: '+proc.stderr[-1000:])
    return 1.0


def play(game, seed, reverse=False, attempt='v1', wall_limit=900):
    c = dict(CONFIG[game])
    if game == 'lunarlander' and attempt == 'v2':
        c['rules'] = '''Land gently on the central pad. State is Gymnasium normalized: x horizontal relative to pad, y height above pad, vx positive right, vy positive UP, angle positive counterclockwise, angular_velocity positive increasing angle. You decide every 5 frames (0.10 sec). The controls have DIFFERENT semantics.
LATERAL CONTROL: positive lateral_engine makes angle DECREASE; negative makes angle INCREASE. First aim for desired_tilt=clip(0.5*x+vx,-0.4,+0.4). Explicit expanded heuristic: lateral_engine=clip(10*angle+20*angular_velocity-10*desired_tilt,-1,+0.995). Compute this expression yourself. A positive angle or positive angular_velocity generally needs POSITIVE lateral_engine to stop the counterclockwise rotation. A negative desired_tilt also generally needs POSITIVE lateral_engine. Side thrust is OFF for abs(lateral_engine)<=0.5; values outside that deadzone fire. Avoid selecting a negative side command just because x or vx is negative: it would rotate the wrong way. If either foot touches, switch lateral off.
MAIN CONTROL: main_engine<=0 is OFF. Any positive value fires at half power or above: power=(main_engine+1)/2. To descend then brake, use the expanded guide main_engine=clip(5.5*abs(x)-10*y-10*vy-1,-1,+0.995). Compute yourself. High altitude with a slow descent needs the main engine OFF. Low altitude with fast negative vy needs the main engine ON. For example a strong downward velocity contributes positively through -10*vy. When either foot touches use main_engine=clip(-10*vy-1,-1,+0.995). Small tilt and low vertical speed are necessary for safe landing. Do not copy previous commands if state has changed. Crashing ends the episode with -100, sleeping safely gives +100, and reward>=200 is the solution score.'''
        c['guidance'] = 'Expanded explicit arithmetic control guidance adapted from the Gymnasium lunar-lander heuristic, with sign/deadzone reminders; Jev computes all choices from raw observations.'
    if game == 'lunarlander' and attempt == 'v3':
        c['effect_labels'] = True
        c['rules'] = '''Land upright, slowly, at x=0. You see normalized observations: x is position right of pad, y is height above pad, vx is rightward velocity, vy is UPWARD velocity, angle and angular_velocity are positive COUNTERCLOCKWISE. Negative vy means falling. Commands last 0.10 simulation seconds.
MAIN ENGINE: negative or zero action turns it OFF. Positive action turns it ON at 50% or more of maximum power. There is no downward engine. Fire strongly when falling fast, especially when near the ground. Coast when rising or falling too slowly at high altitude. Explicit verbal braking guide: compare downward speed (negative of vy) to height y plus about 0.1. If falling speed exceeds that quantity, choose a positive main command to slow descent. If falling more slowly, choose an off command. At very low altitude (y<0.2), aim for only a small downward velocity and no lateral motion. Main thrust above about 0.7 is powerful; it is appropriate while falling rapidly, but turn it off before rising. Once both feet settle with near-zero speed, keep engine off so the lander can sleep.
LATERAL ENGINE: positive command turns CLOCKWISE, reducing angle; negative turns COUNTERCLOCKWISE, increasing angle. Values with magnitude <=0.5 are off. The aim is slightly leftward tilt (negative angle) if x and vx are negative, or slightly rightward tilt (positive angle) if x and vx are positive, capped near +/-0.3 radians, so main thrust brakes horizontal drift. If angle is too positive or is increasing fast, use POSITIVE lateral control. If angle is too negative or decreasing fast, use NEGATIVE lateral control. Anticipate angular momentum; stop adding rotation once already moving toward the desired tilt. Avoid flipping the craft. Do not copy previous actions blindly. On leg contact keep side engines off. A crash ends the episode with -100; sleeping safely gives +100.'''
        c['guidance'] = 'Verbal braking/tilt heuristic and per-interval physical-effect labels. No computed target commands or hidden controller.'
    name = f'{game}-seed{seed}-{attempt}'+('-reverse' if reverse else '')
    out = ROOT/name
    out.mkdir(exist_ok=False)
    shutil.copy2(__file__, out/'runner-snapshot.py')
    (out/'rules.txt').write_text(COMMON+'\n\n'+c['rules'])
    env = gym.make(c['environment'], **c['kwargs'], render_mode='rgb_array', max_episode_steps=c['limit'])
    observation, _ = env.reset(seed=seed)
    unwrapped = env.unwrapped
    client = JevClient(max_calls=2*math.ceil(c['limit']/c['hold']), model=MODEL)
    client._http.timeout = 35.0
    action = [0.0]*len(c['names'])
    history = deque(maxlen=4)
    latencies = []
    total = 0.0
    steps = 0
    decisions = 0
    reason = 'time_limit'
    success = False
    terminated = truncated = False
    started = time.monotonic()
    error = None
    frame_stride = 5 if c['fps']==50 else 3
    video_fps = c['fps']/frame_stride
    video = imageio.get_writer(out/'replay.mp4', fps=video_fps, codec='libx264', macro_block_size=1, quality=7)
    video.append_data(annotate(env.render(), c, seed, steps, total, action, 'initial state'))
    try:
        while steps < c['limit']:
            if time.monotonic()-started > wall_limit-75:
                reason = 'wall_time_budget'; break
            telemetry = observation_dict(game, observation, unwrapped)
            state = {'rules': COMMON+'\n'+c['rules'], 'simulation_step': steps, 'action_hold_frames': c['hold'], 'observation': telemetry, 'recent_history_oldest_to_newest': list(history)}
            t0 = time.monotonic()
            action, trace = decode_action(client, c, state, reverse, out/'api-records.jsonl')
            latency = time.monotonic()-t0
            latencies.append(latency)
            start_step = steps
            reward_before = total
            for _ in range(min(c['hold'], c['limit']-steps)):
                observation, reward, terminated, truncated, _ = env.step(np.asarray(action, dtype=np.float32))
                steps += 1
                total += float(reward)
                if steps % frame_stride == 0 or terminated or truncated:
                    video.append_data(annotate(env.render(), c, seed, steps, total, action))
                if terminated or truncated:
                    break
            row = {'decision': decisions, 'step': start_step, 'observation': telemetry, 'action_names': c['names'], 'action': action, 'executed_frames': steps-start_step, 'latency_s': latency, 'trace': trace, 'reward_increment': total-reward_before, 'reward_total': total, 'terminated': bool(terminated), 'truncated': bool(truncated)}
            with (out/'actions.jsonl').open('a') as f:
                f.write(json.dumps(row)+'\n')
            history.append({'step': start_step, 'observation': telemetry, 'action': action, 'reward_increment': round(total-reward_before, 4)})
            decisions += 1
            if decisions % 10 == 0:
                print(json.dumps({'run': name, 'steps': steps, 'reward': round(total, 2), 'state': observation_dict(game, observation, unwrapped), 'wall_s': round(time.monotonic()-started, 1)}), flush=True)
            if terminated or truncated:
                if game == 'mountaincar':
                    success = bool(terminated and observation[0]>=unwrapped.goal_position and observation[1]>=unwrapped.goal_velocity)
                    reason = 'goal_reached' if success else 'environment_time_limit'
                elif game == 'lunarlander':
                    success = bool(terminated and not unwrapped.lander.awake and not unwrapped.game_over)
                    reason = 'safe_landing' if success else ('crash' if unwrapped.game_over else ('out_of_bounds' if terminated else 'environment_time_limit'))
                else:
                    from gymnasium.envs.box2d.bipedal_walker import TERRAIN_LENGTH, TERRAIN_GRASS, TERRAIN_STEP
                    success = bool(terminated and not unwrapped.game_over and unwrapped.hull.position.x > (TERRAIN_LENGTH-TERRAIN_GRASS)*TERRAIN_STEP)
                    reason = 'terrain_finished' if success else ('fall' if unwrapped.game_over else ('left_boundary' if terminated else 'environment_time_limit'))
                break
    except Exception as exc:
        error = f'{type(exc).__name__}: {exc}'
        reason = 'api_or_runner_error'
    finally:
        video.close()
        (out/'api-records.json').write_text(json.dumps(client.records, indent=2))
        client.close()
    final_frame = annotate(env.render(), c, seed, steps, total, action, reason)
    Image.fromarray(final_frame).save(out/'final.png')
    reader = imageio.get_reader(out/'replay.mp4')
    Image.fromarray(reader.get_data(0)).save(out/'poster.png')
    reader.close()
    preview_speed = make_preview(out, max(1/video_fps, (steps//frame_stride+1)/video_fps))
    summary = {
        'id': name, 'game': game, 'title': c['title'], 'method': 'NumericJev with disclosed control guidance',
        'seed': seed, 'attempt': attempt, 'reverse_options': reverse,
        'environment': c['environment'], 'gymnasium_version': gym.__version__,
        'model': MODEL, 'gateway': 'OpenRouter/systemone', 'trained': False,
        'state_access': 'structured Gymnasium observations; BipedalWalker additionally exposes privileged torso position; no images',
        'guidance': c['guidance'], 'branching': K, 'resolution': str(RESOLUTION),
        'grid': {'low_inclusive': -1, 'high_exclusive': 1, 'points_per_dimension': POINTS, 'depth': 2, 'conditional_candidates': 'min(K, remaining points)', 'execution': 'final interval lower endpoint'},
        'action_dimensions': len(c['names']), 'action_names': c['names'], 'action_hold_frames': c['hold'],
        'reward': total, 'success': success, 'score_threshold_met': bool(total>=200) if game=='lunarlander' else (bool(total>=300) if game=='bipedalwalker' else None),
        'success_definition': {'lunarlander': 'environment terminated, lander asleep, and no body crash', 'mountaincar': 'environment terminated with position >=0.45 and velocity >=0', 'bipedalwalker': 'environment terminated beyond the right terrain finish without falling'}[game],
        'stop_reason': reason, 'terminated': bool(terminated), 'truncated': bool(truncated),
        'steps': steps, 'fps': c['fps'], 'sim_seconds': steps/c['fps'],
        'simulation_time_note': 'MountainCar has discrete steps, displayed seconds use its 30-fps render rate; Box2D games integrate at 50 Hz.',
        'decision_count': decisions, 'api_calls': client.calls,
        'mean_action_latency_s': float(np.mean(latencies)) if latencies else None,
        'p95_action_latency_s': float(np.percentile(latencies,95)) if latencies else None,
        'wall_seconds': time.monotonic()-started, 'wall_time_budget_s': wall_limit,
        'video': str(out/'replay.mp4'), 'gif': str(out/'preview.gif'), 'poster': str(out/'poster.png'),
        'preview_speedup': preview_speed, 'video_api_waits_omitted': True,
        'final_observation': observation_dict(game, observation, unwrapped), 'error': error,
    }
    env.close()
    (out/'summary.json').write_text(json.dumps(summary, indent=2))
    print('RESULT '+json.dumps(summary), flush=True)
    return summary


def smoke():
    """Physics-only diagnostics, explicitly excluded from model evaluation results."""
    results = {'purpose': 'source semantics and physics diagnostic only; these are not Jev episodes', 'gymnasium_version': gym.__version__, 'checks': {}}
    assert partitions(0, 7) == list(range(8))
    assert partitions(0,400) == list(range(0,401,20))
    assert grid_value(399)=='0.995' and grid_value(400)=='1.000'
    for game,c in CONFIG.items():
        env=gym.make(c['environment'], **c['kwargs'])
        o,_=env.reset(seed=7)
        check={'initial_observation': observation_dict(game,o,env.unwrapped), 'action_space':str(env.action_space), 'default_horizon': env.spec.max_episode_steps}
        variants=[]
        if game=='lunarlander':
            probes=[[-1,0],[-1,-1],[-1,1],[0,0],[0.005,0]]
        elif game=='mountaincar':
            probes=[[-1],[0],[0.995]]
        else:
            probes=[[0,0,0,0],[.995,0,0,0],[0,.995,0,0],[-1,0,0,0],[0,-1,0,0]]
        for action in probes:
            env.close()
            env=gym.make(c['environment'], **c['kwargs'])
            env.reset(seed=7)
            o,reward,terminated,truncated,_=env.step(np.asarray(action,dtype=np.float32))
            variants.append({'probe_action':action,'next_observation':observation_dict(game,o,env.unwrapped),'reward':float(reward)})
        check['one_step_probes']=variants
        env.close()
        results['checks'][game]=check
    from gymnasium.envs.box2d import lunar_lander,bipedal_walker
    from gymnasium.envs.classic_control import continuous_mountain_car
    results['source_files']=[{'path':m.__file__,'sha256':hashlib.sha256(Path(m.__file__).read_bytes()).hexdigest()} for m in (lunar_lander,bipedal_walker,continuous_mountain_car)]
    (ROOT/'smoke-semantics.json').write_text(json.dumps(results,indent=2))
    print(json.dumps(results,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--game',choices=list(CONFIG))
    parser.add_argument('--seeds',type=int,nargs='+',default=[7,19])
    parser.add_argument('--reverse',action='store_true')
    parser.add_argument('--attempt',default='v1')
    parser.add_argument('--smoke',action='store_true')
    args=parser.parse_args()
    if args.smoke:
        smoke()
    else:
        credentials()
        for seed in args.seeds:
            play(args.game,seed,args.reverse,args.attempt)
