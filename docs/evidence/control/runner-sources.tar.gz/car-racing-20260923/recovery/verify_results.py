"""Audit saved Jev requests against executed controls and summarize every run."""
import hashlib
import json
from pathlib import Path
import recover

HERE = Path(__file__).resolve().parent


def main():
    summaries = []
    for name in ['NumericJev-seed19', 'NumericJev-seed7', 'NumericJev-seed7-reverse', 'NumericJev-seed19-reverse']:
        out = HERE / 'direct-history-v1' / name
        summary = json.loads((out / 'summary.json').read_text())
        actions = [json.loads(x) for x in (out / 'actions.jsonl').read_text().splitlines()]
        records = json.loads((out / 'api-records.json').read_text())
        baseline = json.loads((HERE.parent / f"geometry-reference-seed{summary['seed']}" / 'summary.json').read_text())
        assert summary['track_sha256'] == baseline['track_sha256']
        assert len(actions) == summary['decision_count']
        assert len(records) == 2 * len(actions) == summary['api_calls']
        assert summary['executed_action_overrides'] == 0
        for index, row in enumerate(actions):
            coarse, fine = records[2*index:2*index+2]
            assert coarse['request']['state'] == fine['request']['state']
            telemetry = coarse['request']['state']['telemetry']
            for key,value in row['telemetry'].items():
                assert telemetry[key] == value
            history = telemetry['recent_controls_oldest_first']
            assert len(history) == min(index,6)
            for hist, previous in zip(history, actions[max(0,index-6):index]):
                assert hist['steering_executed'] == previous['command'][0]
                assert hist['signed_pedal_executed'] == previous['command'][1]
                assert hist['speed_before'] == previous['telemetry']['speed']
            for key,value in zip(['steering','signed_acceleration'],row['command']):
                assert -1 <= value < 1
                choice = fine['response']['answers'][key]['choice']
                description = fine['request']['questions'][key]['criteria'][choice]
                decoded = float(description.split('=')[1].split(':')[0])
                assert abs(decoded-value) < 1e-9
                low,high = row['trace'][-1]['windows'][key]
                assert high-low == 1 and abs(value-(-1+.02*low)) < 1e-9
        summary['observed_zero_speed_nonpositive_pedal_count'] = sum(a['telemetry']['speed'] < .2 and a['command'][1] <= 0 for a in actions)
        # Replay only the decoded actions, without any model or fallback policy.
        env = recover.r.gym.make('CarRacing-v3', continuous=True, max_episode_steps=9000)
        env.reset(seed=summary['seed'])
        replay_steps = 0
        replay_reward = 0.
        replay_offroad = 0
        replay_finished = False
        for row in actions:
            steer,pedal = row['command']
            physical = recover.r.np.array([steer,max(pedal,0),max(-pedal,0)],dtype=recover.r.np.float32)
            for _ in range(min(10,summary['steps']-replay_steps)):
                _,reward,terminated,truncated,info = env.step(physical)
                replay_steps += 1
                replay_reward += reward
                replay_offroad += int(not any(w.tiles for w in env.unwrapped.car.wheels))
                if terminated or truncated:
                    replay_finished = bool(info.get('lap_finished'))
                    assert replay_steps == summary['steps']
            assert env.unwrapped.tile_visited_count == row['visited_tiles']
        assert replay_steps == summary['steps']
        assert abs(replay_reward-summary['reward']) < 1e-6
        assert replay_finished == (summary['stop_reason']=='lap_finished')
        assert abs(100*replay_offroad/replay_steps-summary['fully_offroad_frame_percent']) < 1e-9
        env.close()
        summary['independent_action_replay_verified'] = True
        summary['provider_reported_cost_usd'] = sum(rec['response'].get('usage',{}).get('cost',0) for rec in records)
        summary['recovery_source_sha256'] = hashlib.sha256((out/'recovery-snapshot.py').read_bytes()).hexdigest()
        summary['audit_passed'] = True
        (out/'summary.json').write_text(json.dumps(summary,indent=2))
        summaries.append(summary)
    assert len({s['recovery_source_sha256'] for s in summaries}) == 1
    (HERE/'results.json').write_text(json.dumps(summaries,indent=2))
    lines = [
        '# NumericJev racing recovery: direct controls',
        '',
        'The goal is lap completion using Jev-produced numeric steering and signed throttle/brake. There is no geometric-controller fallback and no programmatic replacement of the selected action.',
        '',
        '## What changed',
        '',
        '- Conservative speed guidance: 12–16 on straight road and 6–10 in tight turns/recovery.',
        '- Explain brake strength: brake 0.10 removed about 6 speed units in 0.2 seconds in the observed simulator. Ask for gentler braking and release before zero speed.',
        '- Explicit low-speed recovery: positive throttle and steering toward the road; steering alone cannot turn a stationary car. State that historical controls are observations, not commands to repeat.',
        '- Include the previous six real control observations/actions and a consecutive stationary-observation duration signal. The signal increments by 0.2 seconds at observations below speed 0.2, so it has one control-step quantization.',
        '- Put these rules directly in both choice questions, as well as the state. Retain exact action descriptions at the final numeric-tree level.',
        '- Increase the simulation horizon from 60 to 180 seconds to allow slower completion. The 10-second no-new-tile guard and 900-second wall limit remain unchanged.',
        '',
        'All changes form one policy revision; this experiment does not isolate which of them contributes how much.',
        '',
        '## Results: all four conditions',
        '',
        '| Seed | Order | Track coverage | Lap finished | Sim seconds | Fully-offroad frames | API calls |',
        '|---|---|---:|---|---:|---:|---:|',
    ]
    for s in summaries:
        order = 'reverse' if s['reverse_options'] else 'forward'
        lines.append(f"| {s['seed']} | {order} | {s['coverage_percent']:.2f}% | {s['stop_reason']=='lap_finished'} | {s['sim_seconds']:.2f} | {s['fully_offroad_frame_percent']:.2f}% | {s['api_calls']} |")
    lines += [
        '',
        '## Verification and limits',
        '',
        'Audited every final selected option against the executed steering/pedal value, numeric leaf index, action bounds, raw current telemetry, and actual preceding six controls. Counts agree at two API requests per control. Same-seed track hashes match the original reference episodes. All four runs used identical recovery source. Independently replaying only the decoded actions reproduces every visited-tile count, final reward, offroad fraction, and termination. This is four exploratory runs on two tracks, not a general driving benchmark.',
        '',
        'The controller receives privileged simulator state and future centerline points, not camera images. Simulation pauses during API calls, and videos omit those waits. Numeric actions are finite-grid values at resolution 0.02, decoded through two ten-way tree levels; no continuous head is trained.',
        '',
        'At the archived final stopped state from the previous seed-19 run, the revised policy chose steering -0.50 and throttle 0.08 in both option orders. Original and revised raw responses are in fixed-state-*.json. Previous failing episodes are preserved outside this directory.',
        '',
        '## Run another episode',
        '',
        '```bash',
        '/tmp/numericjev-racing-env/bin/python /data/yww/notebook/numericjev-game-experiments/car-racing-20260923/recovery/run_recovery.py --seed 19',
        '```',
        '',
        'Append --reverse to reverse option insertion order. Each invocation defaults to a fresh timestamped directory. The runner uses the existing local Jev client and credentials configuration. Every episode saves full API requests/responses, actions, a summary, track geometry, source snapshots, and a video. No GPU is used.',
    ]
    (HERE/'REPORT.md').write_text('\n'.join(lines)+'\n')
    print('AUDIT PASS: all four episodes, every numeric command, full real history, matching tracks, and source identity checked.')
    for s in summaries:
        print(json.dumps({k:s[k] for k in ['seed','reverse_options','coverage_percent','stop_reason','sim_seconds','fully_offroad_frame_percent','observed_zero_speed_nonpositive_pedal_count']}))


if __name__ == '__main__':main()
