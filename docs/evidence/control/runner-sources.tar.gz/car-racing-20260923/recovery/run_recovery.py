"""Reusable entry point; each invocation saves a fresh independent episode."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil

import recover


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seed', type=int, default=19)
    parser.add_argument('--reverse', action='store_true', help='Reverse option insertion order, retaining keys and meanings.')
    parser.add_argument('--output', type=Path, help='A new experiment root; defaults to a timestamped runs/ directory.')
    parser.add_argument('--sim-seconds', type=int, default=180)
    args = parser.parse_args()
    if not 10 <= args.sim_seconds <= 180:
        parser.error('--sim-seconds must be between 10 and 180')
    label = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
    root = args.output or Path(__file__).resolve().parent / 'runs' / label
    root.mkdir(parents=True, exist_ok=True)
    r = recover.r
    r.credentials()
    policy = recover.Policy()
    r.decode_action = policy.decode
    r.ROOT = root.resolve()
    summary = r.play('NumericJev', args.seed, args.reverse, limit=args.sim_seconds * r.FPS)
    out = Path(summary['video']).parent
    shutil.copy2(recover.__file__, out / 'recovery-snapshot.py')
    shutil.copy2(__file__, out / 'entrypoint-snapshot.py')
    summary.update(variant='direct-history-v1', sim_time_limit_s=args.sim_seconds,
                   executed_action_overrides=0, policy_instructions=recover.POLICY, history_controls=6)
    (out / 'summary.json').write_text(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
